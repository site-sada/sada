<?php
require_once __DIR__ . '/config.php';
// حماية على مستوى الصفحة نفسها، مو بس على الـ API: لو ما فيه بريد معلّق
// بجلسة هذا المتصفح تحديدًا (يعني ما سجّل حساب ولا حاول دخول بحساب غير
// مفعّل بهذا المتصفح بالذات)، نرجعه لصفحة الدخول فورًا — قبل حتى ما تُعرض
// له الصفحة. أي قيمة بالرابط (?email=...) تُتجاهل كليًا ولا تُستخدم أبدًا.
if (!empty($_SESSION['user_id'])) {
    header('Location: /feed');
    exit;
}
if (empty($_SESSION['pending_verify_email'])) {
    header('Location: /login');
    exit;
}
// حتى لو نفس المستخدم بنفس الجلسة سايب التبويب مفتوح، الوصول لهذي الصفحة
// له عمر محدد (15 دقيقة، بنفس عمر الكود) — مو مفتوح للأبد بمجرد إنشاء الحساب.
if (empty($_SESSION['pending_verify_until']) || time() > $_SESSION['pending_verify_until']) {
    unset($_SESSION['pending_verify_email'], $_SESSION['pending_verify_until']);
    header('Location: /login');
    exit;
}
$verifyEmail = $_SESSION['pending_verify_email'];

// نتحقق إذا عنده كود تفعيل صالح وواصل من قبل (من التسجيل أو محاولة دخول
// سابقة) — إذا نعم وما كان هذا الكود لتوّه انبعث بهذا الطلب بالذات، نعرض
// له تنبيه بسيط فور فتح الصفحة إنه نفس الكود القديم لسا شغّال، بدل ما
// ننتظر منه يضغط "إعادة إرسال" عشان يعرف.
$hasValidCode = false;
try {
    $stmt = $pdo->prepare("SELECT verify_code, verify_code_expires FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$verifyEmail]);
    $row = $stmt->fetch();
    $hasValidCode = $row && $row['verify_code'] && $row['verify_code_expires']
        && strtotime($row['verify_code_expires']) > time();
} catch (PDOException $e) {
    $hasValidCode = false;
}

// نقارن الكود الموجود حاليًا بقاعدة البيانات بآخر كود عرفنا إننا بعثناه
// بهذه الجلسة (مخزّن كقيمة، مو كعلم يُستهلك مرة وحدة) — طالما نفس الكود
// لسا موجود، فهو "طازج" حتى لو حدّثت الصفحة عدة مرات. يصير "قديم" فقط
// لما يتغيّر الكود (إعادة إرسال فعلية) أو لما يُمسح هذا المتغير صراحة
// (مثلاً برجوع المستخدم يحاول يسجّل دخول من جديد بهذا الحساب لاحقًا).
$justSentNewCode = isset($_SESSION['pending_code_value'], $row['verify_code'])
    && hash_equals((string)$_SESSION['pending_code_value'], (string)$row['verify_code']);

// لو الكود لتوّه انبعث (بهذا الطلب أو بأي طلب سابق من نفس عملية التفعيل)،
// ما نعرض رسالة "ما أرسلنا كود جديد" — هذا بالضبط عكس الحقيقة. نعرضها
// فقط لما يكون فيه كود صالح قديم فعليًا (مثلاً رجع بعدين يحاول يدخل).
$showOldCodeNotice = $hasValidCode && !$justSentNewCode;

$sada_lang = current_lang();
$sada_dir = $sada_lang === 'ar' ? 'rtl' : 'ltr';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($sada_lang ?? 'ar') ?>" dir="<?= htmlspecialchars($sada_dir ?? 'rtl') ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<link rel="preload" as="image" href="/assets/logo-black.png" fetchpriority="high">
<meta name="theme-color" content="#0f0f0f">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
<title data-i18n="verifyPageTitle">تفعيل الحساب — صدى</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#0f0f0f; --ink-soft:#65676b; --ink-faint:#8a8d91; --line:#dbdbdb;
  --bg:#fafafa; --panel:#ffffff; --accent:#1a73e8; --danger:#d93025; --success:#1e7a45;
  --input-bg:#fafafa;
  --btn-text:#ffffff;
  --btn-bg:var(--ink);
  --focus-border:var(--ink);
  --msg-error-bg:#fdecea;
  --msg-success-bg:#e9f7ef;
  --info:#1a73e8;
  --msg-info-bg:#e8f0fe;
  --card-shadow:none;
}
@media (prefers-color-scheme: dark){
  :root{
    --ink:#f2f2f3; --ink-soft:#a9abaf; --ink-faint:#797c81; --line:#2a2b30;
    --bg:#0a0a0c; --panel:#17181c; --accent:#6ea8f5; --danger:#f28b82; --success:#81c995;
    --input-bg:#101114;
    --btn-text:#ffffff;
    --btn-bg:linear-gradient(135deg,#6ea8f5,#4b7fd1);
    --focus-border:#6ea8f5;
    --msg-error-bg:rgba(242,139,130,.14);
    --msg-success-bg:rgba(129,201,149,.14);
    --info:#8ab4f8;
    --msg-info-bg:rgba(138,180,248,.14);
    --card-shadow:0 12px 34px rgba(0,0,0,.55);
  }
}
*{box-sizing:border-box;} html,body{height:100%;margin:0;}
body{ font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,sans-serif; background:var(--bg); color:var(--ink); min-height:100vh; display:flex; flex-direction:column; }
a{color:var(--accent);text-decoration:none;} a:hover{text-decoration:underline;} button{font-family:inherit;}
.topbar{ padding:22px 24px; display:flex; align-items:center; justify-content:space-between; }
.topbar-spacer{ width:76px; }
.logo{ display:flex; align-items:center; gap:10px; font-weight:700; font-size:19px; color:var(--ink); }
.logo-mark{ height:29px; width:auto; display:block; flex-shrink:0; }
.lang-switch{ display:flex; align-items:center; gap:6px; border:1px solid var(--line); background:transparent; color:var(--ink-soft); border-radius:20px; padding:7px 14px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit; transition:border-color .15s ease, color .15s ease; }
.lang-switch:hover{ border-color:var(--ink-faint); color:var(--ink); }
.lang-switch svg{ width:15px; height:15px; }
.wrap{ flex:1; display:flex; align-items:center; justify-content:center; padding:16px 16px 60px; }
.card{ width:100%; max-width:380px; background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:36px 32px; box-shadow:var(--card-shadow); }
.below-card{ width:100%; max-width:380px; text-align:center; margin-top:16px; font-size:13.5px; color:var(--ink-soft); }
.stack{ display:flex; flex-direction:column; align-items:center; }
@media (max-width:480px){ .card{ border:none; padding:20px 6px; } }
.card h1{ font-size:20px; font-weight:700; margin:0 0 6px; text-align:center; }
.card .sub{ font-size:13.5px; color:var(--ink-soft); text-align:center; margin:0 0 26px; }
.field{ margin-bottom:14px; }
.field label{ display:block; font-size:13px; font-weight:500; color:var(--ink); margin-bottom:6px; }
.field .input-shell{ border:1px solid var(--line); border-radius:8px; background:var(--input-bg); transition:border-color .15s ease, background .15s ease; }
.field .input-shell:focus-within{ border-color:var(--focus-border); background:var(--panel); }
.field .input-shell.field-error{ border-color:var(--danger); }
.field input{ width:100%; border:none; outline:none; background:transparent; padding:12px 14px; font-size:14.5px; font-family:inherit; color:var(--ink); border-radius:8px; }
.btn-primary{ width:100%; border:none; border-radius:8px; padding:12.5px; font-weight:700; font-size:14.5px; color:var(--btn-text); background:var(--btn-bg); cursor:pointer; transition:opacity .15s ease; margin-top:6px; }
.btn-primary:hover{ opacity:.88; } .btn-primary[disabled]{ opacity:.5; cursor:default; }
.btn-primary{ display:flex; align-items:center; justify-content:center; gap:8px; }
.spinner{
  display:none; width:15px; height:15px; border-radius:50%;
  border:2px solid color-mix(in srgb, var(--btn-text) 35%, transparent); border-top-color:var(--btn-text);
  animation:spin .7s linear infinite;
}
.spinner.show{ display:inline-block; }
@keyframes spin{ to{ transform:rotate(360deg); } }
.form-msg{ display:none; font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:16px; text-align:center; }
.form-msg.shake{ animation:sada-shake .35s ease; }
@keyframes sada-shake{
  10%,90%{ transform:translateX(-1px); }
  20%,80%{ transform:translateX(2px); }
  30%,50%,70%{ transform:translateX(-4px); }
  40%,60%{ transform:translateX(4px); }
}
.form-msg.show{ display:block; } .form-msg.error{ background:var(--msg-error-bg); color:var(--danger); } .form-msg.success{ background:var(--msg-success-bg); color:var(--success); } .form-msg.info{ background:var(--msg-info-bg); color:var(--info); }
footer{ text-align:center; padding:18px; font-size:12px; color:var(--ink-faint); }

</style>
<link rel="stylesheet" href="/assets/transitions.css?v=20260801i">
<noscript><style>body.sada-pre{opacity:1 !important;}</style></noscript>
<link rel="stylesheet" href="/assets/stepper.css?v=20260801i">
</head>
<body>
<script>document.body.classList.add('sada-pre');</script>
  <div class="topbar">
    <button class="topbar-back" id="backBtn" type="button" aria-label="رجوع" data-i18n-aria="backBtnLabel">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
    </button>
    <a href="/" class="logo">
      <span data-i18n="brand">صدى</span>
      <img src="/assets/logo-black.png" alt="" class="logo-mark" width="30" height="29" loading="eager" fetchpriority="high" decoding="async">
    </a>
    <button class="lang-switch" id="langBtn" type="button">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>
      <span id="langBtnLabel">EN</span>
    </button>
  </div>

  <div class="wrap">
    <div class="stack">
      <div class="sada-stepper-panel">
        <div class="sada-stepper" data-current-step="2">
          <span class="sada-stepper-label" data-step-label="1" data-i18n="stepAccount">الحساب</span>
          <span class="sada-stepper-label" data-step-label="2" data-i18n="stepVerify">التفعيل</span>
          <span class="sada-stepper-label" data-step-label="3" data-i18n="stepUsername">اسم المستخدم</span>
          <span class="sada-stepper-label" data-step-label="4" data-i18n="stepDone">تم</span>
          <div class="sada-stepper-dots">
            <span class="sada-dot" data-step="1"></span>
            <span class="sada-dot" data-step="2"></span>
            <span class="sada-dot" data-step="3"></span>
            <span class="sada-dot" data-step="4"></span>
          </div>
        </div>
      </div>
      <form class="card" id="verifyForm" novalidate>
        <h1 data-i18n="verifyTitle">أدخل كود التفعيل</h1>
        <p class="sub" id="subText" data-i18n="verifySubDefault">أدخل الكود اللي وصلك على بريدك الإلكتروني</p>

        <div class="form-msg" id="formMsg"></div>

        <div class="field">
          <label for="code" data-i18n="activationCodeLabel">كود التفعيل (6 أرقام)</label>
          <div class="input-shell">
            <input id="code" name="code" type="text" inputmode="numeric" maxlength="6"
                   placeholder="000000"
                   style="letter-spacing:10px;font-size:20px;text-align:center;font-family:monospace;">
          </div>
        </div>

        <button class="btn-primary" type="submit" id="submitBtn"><span class="spinner" id="submitSpinner"></span><span id="submitLabel" data-i18n="activateBtn">تفعيل الحساب</span></button>
      </form>

      <div class="below-card">
        <span data-i18n="noCodeQuestion">ما وصلك الكود؟</span> <a href="#" id="resendLink" data-i18n="resendAgain">أعد الإرسال</a>
      </div>
    </div>
  </div>

  <footer>© صدى — جميع الحقوق محفوظة</footer>

    <script src="/assets/i18n.js?v=20260801i"></script>
  <script src="/assets/stepper.js?v=20260801i"></script>
  <script src="/assets/transitions.js?v=20260801i"></script>
  <script>
    window.addEventListener('pageshow', function(e){ if (e.persisted) { window.location.reload(); } });

    // الإيميل يجيني جاهز من السيرفر (مربوط بالجلسة)، مو من رابط المتصفح —
    // حتى لو عدّل أحد الرابط، القيمة هنا ما تتغير لأنها مطبوعة وقت تحميل الصفحة.
    const email = <?php echo json_encode($verifyEmail, JSON_UNESCAPED_UNICODE); ?>;
    const showOldCodeNotice = <?php echo $showOldCodeNotice ? 'true' : 'false'; ?>;
    function renderSubText(){
      const el = document.getElementById('subText');
      if (email) {
        el.removeAttribute('data-i18n');
        el.textContent = SadaI18n.t('verifySubWithEmailPrefix') + email;
      } else {
        el.setAttribute('data-i18n', 'verifySubDefault');
        el.textContent = SadaI18n.t('verifySubDefault');
      }
    }
    document.addEventListener('DOMContentLoaded', function(){
      renderSubText();
      if (showOldCodeNotice) {
        showMsg(SadaI18n.t('existingCodeNotice'), 'info');
      }
    });
    document.addEventListener('click', function(e){
      if (e.target.closest && e.target.closest('#langBtn')) setTimeout(renderSubText, 0);
    });

    const form = document.getElementById('verifyForm');
    const msg = document.getElementById('formMsg');
    const submitBtn = document.getElementById('submitBtn');
    const submitLabel = document.getElementById('submitLabel');
    const submitSpinner = document.getElementById('submitSpinner');
    const resendLink = document.getElementById('resendLink');
    const codeInput = document.getElementById('code');
    const codeShell = codeInput.closest('.input-shell');
    codeInput.addEventListener('input', () => codeShell.classList.remove('field-error'));
    let csrfToken = '';
    fetch('/csrf_token.php').then(r => r.json()).then(d => csrfToken = d.token);
    let lastErrorVibrateAt = 0;
    function vibrateOnError(){
      const now = Date.now();
      if (now - lastErrorVibrateAt < 1500) return; // تجاهل الأخطاء المتكررة بسرعة عشان ما يصير اهتزاز مزعج متواصل
      lastErrorVibrateAt = now;
      if ('vibrate' in navigator) { try { navigator.vibrate(200); } catch (e) {} }
      msg.classList.remove('shake'); void msg.offsetWidth; msg.classList.add('shake');
    }
    function showMsg(text, type){ msg.textContent = text; msg.className = 'form-msg show ' + type; if (type === 'error') vibrateOnError(); }

    codeInput.addEventListener('input', function(){ this.value = this.value.replace(/\D/g, '').slice(0, 6); });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.className = 'form-msg';
      codeShell.classList.remove('field-error');
      const code = codeInput.value.trim();
      if (!email) { showMsg(SadaI18n.t('noEmailSpecified'), 'error'); return; }
      if (!code) { showMsg(SadaI18n.t('errEnterVerifyCode'), 'error'); codeShell.classList.add('field-error'); codeInput.focus(); return; }
      if (code.length !== 6) { showMsg(SadaI18n.t('errCode6Digits'), 'error'); codeShell.classList.add('field-error'); codeInput.focus(); return; }

      submitBtn.disabled = true; submitLabel.textContent = SadaI18n.t('verifyChecking'); submitSpinner.classList.add('show');

      try {
        const res = await fetch('/verify_code.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, code, csrf_token: csrfToken })
        });
        const data = await res.json();

        if (data.success) {
          showMsg(data.message + SadaI18n.t('redirectingSuffix'), 'success');
          if (window.SadaStepper) window.SadaStepper.advanceTo(3);
          // بعد التفعيل مباشرة لازم يختار اسم المستخدم — خطوة إلزامية
          // ضمن إنشاء الحساب، قبل ما يوصل لأي صفحة ثانية.
          setTimeout(() => { window.location.href = '/choose-username'; }, 1500);
        } else {
          codeShell.classList.add('field-error');
          showMsg(data.message, 'error');
          submitBtn.disabled = false; submitLabel.textContent = SadaI18n.t('activateBtn'); submitSpinner.classList.remove('show');
        }
      } catch (err) {
        showMsg(SadaI18n.t('networkError'), 'error');
        submitBtn.disabled = false; submitLabel.textContent = SadaI18n.t('activateBtn'); submitSpinner.classList.remove('show');
      }
    });

    resendLink.addEventListener('click', async (e) => {
      e.preventDefault();
      if (!email) return;
      // يمنع نقرات متكررة سريعة ترسل أكثر من طلب متزامن قبل ما يرجع رد أول طلب
      if (resendLink.dataset.sending === '1') return;
      resendLink.dataset.sending = '1';
      resendLink.style.pointerEvents = 'none';
      resendLink.style.opacity = '0.6';
      resendLink.textContent = SadaI18n.t('resendSending');
      try {
        const res = await fetch('/resend_verification.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, csrf_token: csrfToken })
        });
        const data = await res.json();
        showMsg(data.message, data.success ? 'success' : 'error');
        if (data.hasValidCode) {
          // الرسالة تقول له "استخدم الكود" — نوصّله فورًا لنفس الحقل اللي يكتبه فيه
          const codeInput = document.getElementById('code');
          codeInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
          codeInput.focus();
        }
      } catch (err) { showMsg(SadaI18n.t('networkErrorShort'), 'error'); }
      finally {
        resendLink.textContent = SadaI18n.t('resendAgain');
        resendLink.dataset.sending = '0';
        resendLink.style.pointerEvents = '';
        resendLink.style.opacity = '';
      }
    });
  </script>
</body>
</html>
