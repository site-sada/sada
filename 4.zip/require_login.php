<?php
/**
 * ضع هذا السطر في أعلى أي صفحة تبي تحميها (مثل feed.php)
 * require_once 'require_login.php';
 */
require_once __DIR__ . '/config.php';

if (empty($_SESSION['user_id'])) {
    header('Location: /login');
    exit;
}
// الحساب لازم يكون مكتمل 100% (بريد مفعّل + اسم مستخدم مختار) — handle
// بالجلسة ما يُضبط إلا بعد اكتمال الخطوتين معًا (راجع set_username.php).
if (empty($_SESSION['handle'])) {
    header('Location: /choose-username');
    exit;
}
