<?php
/**
 * إرسال إيميل حقيقي عبر Resend API (HTTPS/cURL) — بدون SMTP إطلاقًا
 * هذا يتجاوز مشكلة حجب بورتات SMTP (587/465) الشائعة بالاستضافة المجانية،
 * لأن HTTPS العادي (بورت 443) نادرًا ما يكون محجوب.
 *
 * ملاحظة عن وصول الإيميلات لصندوق Spam رغم توثيق SPF/DKIM/DMARC:
 * توثيق الدومين بـ Resend يثبت إن الإيميل "أصلي" وما أحد انتحل هويتك،
 * لكنه لا يضمن الوصول للوارد — فيه عامل ثاني منفصل تمامًا وهو "سمعة الدومين
 * والـ IP" (Domain/IP Reputation) عند Gmail/Outlook/ياهو، وهذا يُبنى بالوقت
 * حسب سجل الإرسال. الدومين المستخدم هنا (sada.abrdns.com) هو subdomain مجاني
 * من مزوّد DNS ديناميكي (abrdns.com) يشترك فيه آلاف المستخدمين المختلفين —
 * لو أي واحد منهم أساء استخدامه بالماضي، سمعة الدومين كلها تتأثر بغض النظر
 * عن إعداداتك الصحيحة. أفضل حل جذري: احصل على دومين مخصص فعلي (حتى لو رخيص)
 * ووثّقه بـ Resend، وابدأ الإرسال تدريجيًا بأعداد قليلة أول أسبوعين لبناء سمعة
 * نظيفة. التحسينات بالكود هنا (بدون صور خارجية، بدون نص مخفي مبالغ فيه،
 * محتوى نظيف ومختصر) تقلل الاحتمالية لكنها لا تلغي أثر سمعة الدومين نفسه.
 */
function send_email(string $to, string $subject, string $htmlBody, string $textBody = ''): bool {
    global $RESEND_API_KEY, $MAIL_FROM, $MAIL_FROM_NAME, $SITE_URL;

    if ($textBody === '') {
        $textBody = trim(strip_tags(str_replace(['<br>', '<br/>', '</p>'], "\n", $htmlBody)));
    }

    $payload = json_encode([
        "from"     => "{$MAIL_FROM_NAME} <{$MAIL_FROM}>",
        "to"       => [$to],
        "reply_to" => $MAIL_FROM,
        "subject"  => $subject,
        "html"     => $htmlBody,
        "text"     => $textBody,
        // رؤوس تزيد ثقة السيرفرات المستقبِلة بأن هذي رسالة نظام حقيقية وليست حملة إعلانية
        "headers"  => [
            "X-Entity-Ref-ID" => uniqid('sada_', true),
        ],
    ]);

    $ch = curl_init("https://api.resend.com/emails");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer {$RESEND_API_KEY}",
            "Content-Type: application/json",
            "Accept: application/json",
        ],
        CURLOPT_TIMEOUT => 12,
    ]);

    $response  = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $ok = $httpCode >= 200 && $httpCode < 300;

    // سجلّ الأخطاء يبقى محليًا فقط للمطوّر (غير مقروء من المتصفح — راجع .htaccess)
    // ولا يُعرض أبدًا للمستخدم النهائي.
    if (!$ok) {
        $log = "[" . date('Y-m-d H:i:s') . "] to={$to} httpCode={$httpCode} curlError=\"{$curlError}\" response={$response}\n";
        @file_put_contents(__DIR__ . '/mail_debug.log', $log, FILE_APPEND);
    }

    return $ok;
}

/**
 * قالب إيميل احترافي موحّد — بنفس شعار الموقع (دائرتان)، بسيط ونظيف.
 * الشعار مرسوم بـ HTML/CSS خالص (بدون أي صورة خارجية) عشان:
 *  ١) يظهر فورًا حتى لو المستخدم مسوٍّ حظر تحميل الصور بإيميله (افتراضي بكثير من العملاء)
 *  ٢) صور خارجية أقل = نقاط سبام أقل، ويرفع من احتمالية الوصول لصندوق الوارد
 */
function email_template(string $bodyHtml, string $preheader = ''): string {
    global $SITE_URL;
    $site = $SITE_URL ?? 'https://sada.app';
    $year = date('Y');

    // نص مخفي يظهر بمعاينة الإيميل بقائمة الوارد (قبل الفتح) — يحسّن الشكل الأول اللي يشوفه المستخدم
    // ملاحظة: الحشو محدود عمدًا (بدل تكرار كبير) لأن النص المخفي المبالغ فيه إشارة سبام معروفة عند بعض الفلاتر
    $preheaderHtml = $preheader !== ''
        ? "<div style='display:none;max-height:0;overflow:hidden;opacity:0;mso-hide:all;'>" . htmlspecialchars($preheader) . "</div>"
        : '';

    return "
    {$preheaderHtml}
    <div dir='rtl' style='background:#f2f2f5;padding:40px 16px;font-family:Tahoma,Arial,sans-serif;'>
      <div style='max-width:440px;margin:0 auto;'>

        <!-- شعار صدى: الاسم ثم الشعار (بالعربي بالإيميل، فالشعار يصير يمّ الاسم من اليسار) -->
        <div style='text-align:center;margin-bottom:28px;'>
          <table role='presentation' align='center' cellpadding='0' cellspacing='0' border='0'>
            <tr>
              <td style='vertical-align:middle;'>
                <span style='font-weight:800;font-size:18px;color:#0f0f0f;font-family:Tahoma,Arial,sans-serif;line-height:1;'>صدى</span>
              </td>
              <td style='padding-inline-start:8px;vertical-align:middle;'>
                <img src='{$site}/assets/logo-black.png' width='21' height='20' alt='' style='display:block;width:21px;height:20px;border:0;outline:none;' />
              </td>
            </tr>
          </table>
        </div>

        <div style='background:#ffffff;border-radius:16px;border:1px solid #e8e8ec;overflow:hidden;'>
          <div style='padding:30px 28px;text-align:right;color:#0f0f0f;'>
            {$bodyHtml}
          </div>
        </div>

        <div style='padding:22px 12px 0;text-align:center;'>
          <p style='color:#9a9ca3;font-size:12px;margin:0 0 6px;line-height:1.8;'>
            هذي رسالة تلقائية من <a href='{$site}' style='color:#9a9ca3;text-decoration:underline;'>منصة صدى</a>، ما تحتاج ترد عليها.
          </p>
          <p style='color:#b4b6bc;font-size:11.5px;margin:0;line-height:1.8;'>
            © {$year} صدى. جميع الحقوق محفوظة.
          </p>
        </div>

      </div>
    </div>";
}
