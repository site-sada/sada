-- شغّل هذا الملف مرة وحدة بس، لأن جدول users عندك موجود من قبل
-- (نفس مكان تشغيل schema.sql: phpMyAdmin > قاعدة بياناتك > تبويب SQL)

ALTER TABLE users
    ADD COLUMN email_verified TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN verify_token VARCHAR(64) NULL;
