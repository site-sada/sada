<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mailer.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$email = normalize_email($data['email'] ?? '');
$ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('invalidEmail')]);
    exit;
}

// فحص جدول الرسائل المرتدة قبل أي محاولة إعادة إرسال كود — لو البريد
// مسجّل كبريد غير صالح (Bounce دائم)، لا نرسل شي.
if (email_bounce_is_blocked($pdo, $email)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('emailBounced')]);
    exit;
}

// نفس فحص الأمان بـ verify_code.php: ما نسمح بإعادة إرسال كود لأي بريد إلا
// إذا كان مطابق للبريد المربوط بهذي الجلسة تحديدًا.
if (!isset($_SESSION['pending_verify_email']) || $_SESSION['pending_verify_email'] !== $email) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

// نفس الرسالة سواء الحساب موجود أو لا، حتى لا نكشف عن وجود الحساب من عدمه
$generic = ["success" => true, "message" => msg('resendGeneric')];

$stmt = $pdo->prepare("SELECT id, name, email_verified, verify_code, verify_code_expires FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || $user['email_verified']) {
    echo json_encode($generic);
    exit;
}

// أهم فحص: هل عنده أصلًا كود تفعيل لسا ضمن مدة صلاحيته (١٥ دقيقة)؟ لو نعم
// ما نولّد ولا نرسل كود جديد أبدًا — نفس الكود القديم لسا شغّال، فقط نخبره
// ونوجّهه لصفحة إدخاله. توليد كود جديد بدون داعٍ يلغي القديم ويربك المستخدم.
$hasValidCode = $user['verify_code'] && $user['verify_code_expires']
    && strtotime($user['verify_code_expires']) > time();

if ($hasValidCode) {
    // ما تغيّر شي فعليًا (ما ولّدنا ولا بعثنا كود جديد) — فلا داعي نلمس
    // حالة "الكود الطازج"، تبقى كما كانت.
    $_SESSION['pending_verify_until'] = max(
        $_SESSION['pending_verify_until'] ?? 0,
        strtotime($user['verify_code_expires'])
    );
    echo json_encode([
        "success" => true,
        "message" => msg('hasValidCodeUseIt'),
        "hasValidCode" => true,
    ]);
    exit;
}

// ما فيه كود صالح — هذا فعليًا طلب توليد وإرسال كود جديد، فنطبّق حد المحاولات هنا
if (too_many_attempts($pdo, $ip, $email, 4, 15)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}
record_attempt($pdo, $ip, $email);

$_SESSION['pending_verify_until'] = time() + 15 * 60;
$code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$expiresAt = date('Y-m-d H:i:s', time() + 15 * 60);
$pdo->prepare(
    "UPDATE users SET verify_code = ?, verify_code_expires = ? WHERE id = ?"
)->execute([$code, $expiresAt, $user['id']]);

send_email(
    $email,
    "كود تفعيل حسابك في صدى: {$code}",
    email_template("
        <h2 style='margin:0 0 6px;font-size:19px;'>مرحبًا {$user['name']}</h2>
        <p style='color:#5b5d63;font-size:14.5px;line-height:1.8;margin:0 0 24px;'>
            إليك رمز تفعيل جديد لحسابك في صدى، صالح لمدة ١٥ دقيقة.
        </p>
        <div style='background:#0f0f0f;border-radius:14px;padding:22px;text-align:center;margin-bottom:22px;'>
            <div style='color:#9a9ca3;font-size:11px;font-weight:600;letter-spacing:2px;margin-bottom:10px;'>رمز التفعيل</div>
            <div style='font-size:34px;font-weight:800;letter-spacing:10px;color:#ffffff;font-family:Tahoma,Arial,sans-serif;direction:ltr;'>{$code}</div>
        </div>
        <p style='color:#9a9ca3;font-size:12.5px;line-height:1.8;margin:0;'>
            لو ما طلبت هذا الرمز، تقدر تتجاهل الرسالة بأمان.
        </p>
    ", "رمز تفعيل حسابك في صدى: {$code}")
);

// نفس فكرة register.php — نخزن قيمة الكود الجديد نفسه، فلما تفتح صفحة
// verify.php (أو تحدّثها) ما لازم تشوف رسالة "ما أرسلنا كود جديد".
$_SESSION['pending_code_value'] = $code;

echo json_encode($generic);
