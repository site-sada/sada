<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$email = trim($data['email'] ?? '');
$code  = trim($data['code'] ?? '');
$ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{6}$/', $code)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('enterCode6')]);
    exit;
}

// أمان: البريد يجب يطابق البريد المربوط بهذي الجلسة (اللي انضبط وقت التسجيل
// أو محاولة الدخول). يمنع أي شخص من تغيير الإيميل بالرابط ومحاولة تفعيل
// حساب غيره — بدون هذا الفحص كان أي زائر يقدر يستهدف أي بريد إلكتروني.
if (!isset($_SESSION['pending_verify_email']) || $_SESSION['pending_verify_email'] !== $email) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}
if (empty($_SESSION['pending_verify_until']) || time() > $_SESSION['pending_verify_until']) {
    unset($_SESSION['pending_verify_email'], $_SESSION['pending_verify_until']);
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

if (too_many_attempts($pdo, $ip, $email, 8, 15)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}

$stmt = $pdo->prepare(
    "SELECT id, name, handle, pin_hash, verify_code, verify_code_expires
     FROM users WHERE email = ? LIMIT 1"
);
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !$user['verify_code']) {
    record_attempt($pdo, $ip, $email);
    http_response_code(404);
    echo json_encode(["success" => false, "message" => msg('noVerifyRequestForEmail')]);
    exit;
}

if (strtotime($user['verify_code_expires']) < time()) {
    http_response_code(410);
    echo json_encode(["success" => false, "message" => msg('codeExpired')]);
    exit;
}

if (!hash_equals($user['verify_code'], $code)) {
    record_attempt($pdo, $ip, $email);
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('incorrectCode')]);
    exit;
}

// الكود صحيح — فعّل الحساب
$pdo->prepare(
    "UPDATE users SET email_verified = 1, verify_code = NULL, verify_code_expires = NULL WHERE id = ?"
)->execute([$user['id']]);

unset($_SESSION['pending_verify_email'], $_SESSION['pending_verify_until']);
session_regenerate_id(true);
$_SESSION['user_id'] = $user['id'];
$_SESSION['name']    = $user['name'];
$_SESSION['handle']  = $user['handle'];

echo json_encode([
    "success" => true,
    "message" => msg('accountActivated'),
    "has_pin" => !empty($user['pin_hash'])
]);
