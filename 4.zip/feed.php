<?php
require_once __DIR__ . '/config.php';
// حماية حقيقية على مستوى السيرفر — أي دخول مباشر بدون جلسة صالحة يُرفض هنا.
// الحساب "المكتمل" فقط هو اللي عنده user_id + handle معًا (اسم المستخدم
// يُضبط بالجلسة فقط بعد ما يختاره فعليًا بصفحة /choose-username) — لو ناقص،
// نوديه يكمل هناك بدل ما نعرض له الصفحة الرئيسية بحساب غير مكتمل.
if (empty($_SESSION['user_id'])) {
    header('Location: /login');
    exit;
}
if (empty($_SESSION['handle'])) {
    header('Location: /choose-username');
    exit;
}

// تحقق سيرفر حقيقي على تفضيل اللغة: كوكيز محفوظة إن وُجدت، وإلا لغة نظام
// المستخدم من رأس Accept-Language (current_lang في messages.php) — يخلي
// اللغة الصحيحة تُطبّق من أول رندر بدون "فلاش" اتجاه خاطئ
$sada_lang = current_lang();
$sada_dir = $sada_lang === 'ar' ? 'rtl' : 'ltr';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($sada_lang) ?>" dir="<?= htmlspecialchars($sada_dir) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<link rel="preload" as="image" href="/assets/logo-white.png" fetchpriority="high">
<meta name="theme-color" content="#0f0f0f">
<title data-i18n="feedPageTitle">صدى</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@700;800;900&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<style>
  :root{
    --bg:#0a0e1a;
    --bg-2:#0d1226;
    --surface:rgba(255,255,255,0.045);
    --surface-strong:rgba(255,255,255,0.08);
    --border:rgba(255,255,255,0.09);
    --text:#f2f1fb;
    --text-soft:#a3a8cc;
    --text-dim:#6d7295;
    --magenta:#ff3d8a;
    --cyan:#22d3ee;
    --violet:#8b5cf6;
    --amber:#ffb020;
    --echo-gradient:linear-gradient(135deg, var(--magenta), var(--violet) 55%, var(--cyan));
    --radius:16px;
  }
  *{box-sizing:border-box;}
  html,body{height:100%;}
  body{
    margin:0;
    background:var(--bg);
    color:var(--text);
    font-family:"Tajawal", sans-serif;
    min-height:100vh;
    position:relative;
    overflow-x:hidden;
  }
  @media (prefers-reduced-motion: reduce){
    *{animation-duration:0.001ms !important; animation-iteration-count:1 !important; transition-duration:0.001ms !important;}
  }

  /* ambient aurora backdrop */
  .aurora{
    position:fixed; inset:-10%;
    z-index:0;
    background:
      radial-gradient(32% 38% at 85% 8%, rgba(255,61,138,0.20), transparent 60%),
      radial-gradient(35% 40% at 8% 20%, rgba(34,211,238,0.14), transparent 60%),
      radial-gradient(30% 35% at 50% 95%, rgba(139,92,246,0.16), transparent 60%);
    filter:blur(30px);
    animation:auroraShift 22s ease-in-out infinite alternate;
    pointer-events:none;
  }
  @keyframes auroraShift{
    0%{ transform:translate3d(0,0,0) scale(1); }
    100%{ transform:translate3d(-2%, 3%, 0) scale(1.08); }
  }

  a{ color:inherit; text-decoration:none; }
  button{ font-family:inherit; }

  .app{
    position:relative;
    z-index:1;
    display:flex;
    max-width:1180px;
    margin:0 auto;
    min-height:100vh;
  }

  /* ---------------- right: nav sidebar ---------------- */
  .nav{
    flex:0 0 260px;
    padding:22px 18px;
    display:flex;
    flex-direction:column;
    gap:6px;
    border-left:1px solid var(--border);
    position:sticky;
    top:0;
    height:100vh;
  }
  .logo{
    display:flex;
    align-items:center;
    gap:10px;
    font-family:"Cairo", sans-serif;
    font-weight:900;
    font-size:22px;
    padding:8px 12px 22px;
  }
  .logo-mark{
    height:30px; width:auto; display:block; flex-shrink:0;
  }

  .nav-item{
    display:flex;
    align-items:center;
    gap:14px;
    padding:12px 14px;
    border-radius:999px;
    font-size:16px;
    font-weight:500;
    color:var(--text-soft);
    cursor:pointer;
    transition:background .2s ease, color .2s ease;
  }
  .nav-item svg{ width:23px; height:23px; flex-shrink:0; }
  .nav-item:hover{ background:var(--surface); color:var(--text); }
  .nav-item.active{
    color:var(--text);
    font-weight:700;
  }
  .nav-item.active svg{ color:var(--magenta); }
  .nav-item .badge{
    margin-inline-start:auto;
    background:var(--amber);
    color:#241300;
    font-size:11px;
    font-weight:800;
    border-radius:999px;
    padding:1px 7px;
  }

  .compose-btn{
    margin-top:18px;
    border:none;
    cursor:pointer;
    padding:15px;
    border-radius:999px;
    background:var(--echo-gradient);
    color:#fff;
    font-family:"Cairo", sans-serif;
    font-weight:800;
    font-size:16px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    box-shadow:0 10px 26px rgba(255,61,138,0.28);
    transition:transform .18s ease, box-shadow .25s ease;
    position:relative;
    overflow:hidden;
  }
  .compose-btn:hover{ transform:translateY(-2px); box-shadow:0 14px 32px rgba(139,92,246,0.36); }
  .compose-btn:active{ transform:translateY(0); }

  .nav-profile{
    margin-top:auto;
    display:flex;
    align-items:center;
    gap:10px;
    padding:10px;
    border-radius:14px;
    cursor:pointer;
    transition:background .2s ease;
  }
  .nav-profile:hover{ background:var(--surface); }
  .avatar{
    width:40px;height:40px;border-radius:50%;
    display:flex;align-items:center;justify-content:center;
    font-family:"Cairo",sans-serif; font-weight:800; font-size:14px;
    color:#fff; flex-shrink:0;
  }
  .nav-profile .who{ line-height:1.3; overflow:hidden; }
  .nav-profile .who .name{ font-size:14px; font-weight:700; }
  .nav-profile .who .handle{ font-size:12.5px; color:var(--text-dim); }

  /* ---------------- center: feed ---------------- */
  .feed{
    flex:1 1 auto;
    min-width:0;
    border-left:1px solid var(--border);
  }
  .feed-head{
    position:sticky; top:0;
    z-index:3;
    backdrop-filter:blur(14px);
    background:rgba(10,14,26,0.75);
    padding:16px 22px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
  }
  .feed-head h1{
    font-family:"Cairo", sans-serif;
    font-size:19px;
    font-weight:800;
    margin:0;
  }
  .feed-head .live{
    display:flex; align-items:center; gap:6px;
    font-size:12px; color:var(--text-dim);
  }
  .feed-head .dot{
    width:7px;height:7px;border-radius:50%;
    background:var(--cyan);
    box-shadow:0 0 0 0 rgba(34,211,238,0.5);
    animation:dotPulse 2s ease-out infinite;
  }
  @keyframes dotPulse{
    0%{ box-shadow:0 0 0 0 rgba(34,211,238,0.45); }
    70%{ box-shadow:0 0 0 8px rgba(34,211,238,0); }
    100%{ box-shadow:0 0 0 0 rgba(34,211,238,0); }
  }

  .composer{
    padding:18px 22px;
    border-bottom:1px solid var(--border);
    display:flex;
    gap:14px;
  }
  .composer textarea{
    flex:1;
    resize:none;
    background:transparent;
    border:none;
    outline:none;
    color:var(--text);
    font-family:inherit;
    font-size:16.5px;
    min-height:52px;
    padding-top:10px;
  }
  .composer textarea::placeholder{ color:var(--text-dim); }
  .composer-foot{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-top:10px;
  }
  .composer-icons{ display:flex; gap:6px; }
  .icon-btn{
    width:36px;height:36px;
    border-radius:50%;
    border:none;
    background:transparent;
    color:var(--cyan);
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;
    transition:background .2s ease;
  }
  .icon-btn:hover{ background:rgba(34,211,238,0.12); }
  .icon-btn svg{ width:19px; height:19px; }
  .post-submit{
    border:none; cursor:pointer;
    padding:9px 22px;
    border-radius:999px;
    background:var(--echo-gradient);
    color:#fff;
    font-weight:800;
    font-family:"Cairo", sans-serif;
    font-size:14.5px;
    opacity:0.5;
    transition:opacity .2s ease, transform .15s ease;
  }
  .post-submit.ready{ opacity:1; }
  .post-submit.ready:hover{ transform:translateY(-1px); }

  .post{
    display:flex;
    gap:14px;
    padding:18px 22px;
    border-bottom:1px solid var(--border);
    animation:rise .5s cubic-bezier(.2,.7,.2,1) backwards;
    transition:background .15s ease;
  }
  .post:hover{ background:rgba(255,255,255,0.015); }
  @keyframes rise{
    from{ opacity:0; transform:translateY(10px); }
    to{ opacity:1; transform:translateY(0); }
  }

  .post-body{ flex:1; min-width:0; }
  .post-head{
    display:flex; align-items:center; gap:6px;
    font-size:14.5px;
    flex-wrap:wrap;
  }
  .post-head .name{ font-weight:700; }
  .post-head .handle, .post-head .time{ color:var(--text-dim); font-size:13.5px; }
  .post-text{
    margin:6px 0 12px;
    font-size:15.5px;
    line-height:1.85;
    color:#e8e6f7;
  }
  .post-text .tag{ color:var(--cyan); }

  .post-media{
    border-radius:14px;
    border:1px solid var(--border);
    height:200px;
    margin-bottom:12px;
    background:linear-gradient(135deg, rgba(139,92,246,0.22), rgba(34,211,238,0.14));
    display:flex; align-items:center; justify-content:center;
    color:var(--text-dim);
    font-size:13px;
  }

  .post-actions{
    display:flex;
    justify-content:space-between;
    max-width:340px;
    margin-top:4px;
  }
  .action{
    display:flex; align-items:center; gap:6px;
    background:none; border:none; cursor:pointer;
    color:var(--text-dim);
    font-size:13px;
    padding:6px 8px;
    border-radius:999px;
    position:relative;
    transition:color .2s ease, background .2s ease;
  }
  .action svg{ width:18px; height:18px; }
  .action.reply:hover{ color:var(--cyan); background:rgba(34,211,238,0.1); }
  .action.repost:hover{ color:#34d399; background:rgba(52,211,153,0.1); }
  .action.like:hover{ color:var(--magenta); background:rgba(255,61,138,0.1); }
  .action.echo:hover{ color:var(--amber); background:rgba(255,176,32,0.1); }
  .action.liked{ color:var(--magenta); }
  .action.liked svg{ fill:var(--magenta); }
  .action.reposted{ color:#34d399; }

  .ripple{
    position:absolute;
    inset:0;
    border-radius:999px;
    pointer-events:none;
  }
  .ripple span{
    position:absolute; inset:0;
    border-radius:50%;
    border:1.5px solid var(--magenta);
    opacity:0;
  }
  .ripple.go span{ animation:echoRing .6s ease-out; }
  @keyframes echoRing{
    0%{ transform:scale(0.4); opacity:0.7; }
    100%{ transform:scale(2.6); opacity:0; }
  }

  /* ---------------- left: trends / suggestions ---------------- */
  .side{
    flex:0 0 280px;
    padding:22px 18px;
    display:flex;
    flex-direction:column;
    gap:20px;
  }
  .search-shell{
    display:flex; align-items:center; gap:10px;
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:999px;
    padding:11px 16px;
    transition:border-color .2s ease, box-shadow .2s ease;
  }
  .search-shell:focus-within{
    border-color:var(--violet);
    box-shadow:0 0 0 4px rgba(139,92,246,0.15);
  }
  .search-shell input{
    background:none; border:none; outline:none;
    color:var(--text); font-family:inherit; font-size:14px; flex:1;
  }
  .search-shell svg{ width:17px; height:17px; color:var(--text-dim); flex-shrink:0; }

  .panel{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    overflow:hidden;
  }
  .panel h3{
    font-family:"Cairo", sans-serif;
    font-size:16.5px;
    font-weight:800;
    margin:0;
    padding:16px 18px 10px;
  }
  .trend{
    padding:10px 18px;
    cursor:pointer;
    transition:background .15s ease;
  }
  .trend:hover{ background:var(--surface-strong); }
  .trend .cat{ font-size:11.5px; color:var(--text-dim); }
  .trend .tag{ font-size:14.5px; font-weight:700; margin:2px 0; color:var(--text); }
  .trend .vol{ font-size:12px; color:var(--text-dim); }

  .follow-row{
    display:flex; align-items:center; gap:10px;
    padding:10px 18px;
  }
  .follow-row .who{ flex:1; min-width:0; line-height:1.3; }
  .follow-row .name{ font-size:14px; font-weight:700; }
  .follow-row .handle{ font-size:12.5px; color:var(--text-dim); }
  .follow-btn{
    border:none; cursor:pointer;
    background:#fff; color:#100c1c;
    font-weight:800; font-size:12.5px;
    padding:7px 14px; border-radius:999px;
    transition:opacity .2s ease;
  }
  .follow-btn:hover{ opacity:0.85; }

  .panel-foot-link{
    display:block;
    padding:12px 18px 16px;
    font-size:13px;
    color:var(--cyan);
  }
  .panel-foot-link:hover{ text-decoration:underline; }

  /* ---------------- mobile ---------------- */
  @media (max-width:1020px){
    .side{ display:none; }
  }
  @media (max-width:760px){
    .nav{
      position:fixed; bottom:0; right:0; left:0; top:auto;
      height:auto; width:100%;
      flex-direction:row;
      justify-content:space-around;
      align-items:center;
      padding:8px 6px;
      border-left:none;
      border-top:1px solid var(--border);
      background:rgba(10,14,26,0.9);
      backdrop-filter:blur(14px);
      z-index:5;
    }
    .logo, .nav-profile, .compose-btn span{ display:none; }
    .compose-btn{ margin:0; width:44px; height:44px; padding:0; border-radius:50%; }
    .nav-item{ padding:10px; }
    .nav-item span{ display:none; }
    body{ padding-bottom:70px; }
  }
</style>
</head>
<body>
<div class="aurora"></div>

<div class="app">

  <!-- right sidebar: nav -->
  <nav class="nav">
    <div class="logo"><span data-i18n="brand">صدى</span><img src="/assets/logo-white.png" alt="" class="logo-mark" width="31" height="30" loading="eager" fetchpriority="high" decoding="async"></div>

    <div class="nav-item active">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 11.5 12 4l8 7.5"/><path d="M6 10v9a1 1 0 0 0 1 1h4v-6h2v6h4a1 1 0 0 0 1-1v-9"/></svg>
      <span data-i18n="homeTitle">الرئيسية</span>
    </div>
    <div class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
      <span data-i18n="exploreTitle">استكشاف</span>
    </div>
    <div class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
      <span data-i18n="notificationsTitle">الإشعارات</span>
      <span class="badge">5</span>
    </div>
    <div class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span data-i18n="messagesTitle">الرسائل</span>
    </div>
    <div class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>
      <span data-i18n="savedTitle">المحفوظات</span>
    </div>
    <div class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>
      <span data-i18n="profileTitle">الملف الشخصي</span>
    </div>

    <button class="compose-btn">
      <span data-i18n="composeBtnLabel">غرّد بصدى</span>
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>
    </button>

    <button class="lang-switch" id="langBtn" type="button" style="margin:8px 4px 0;display:flex;align-items:center;gap:6px;border:1px solid var(--border);background:transparent;color:var(--text-soft);border-radius:20px;padding:7px 14px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>
      <span id="langBtnLabel"><?= $sada_lang === 'ar' ? 'EN' : 'AR' ?></span>
    </button>

    <div class="nav-profile" id="navProfile" style="position:relative;">
      <div class="avatar" style="background:linear-gradient(135deg,var(--violet),var(--cyan));"><?= htmlspecialchars(mb_substr($_SESSION['name'] ?? 'ص', 0, 1)) ?></div>
      <div class="who">
        <div class="name"><?= htmlspecialchars($_SESSION['name'] ?? '') ?></div>
        <div class="handle">‎@<?= htmlspecialchars($_SESSION['handle'] ?? '') ?></div>
      </div>
      <a href="/logout" style="margin-inline-start:auto;color:var(--text-dim);font-size:12px;" data-i18n="logoutLabel">خروج</a>
    </div>
  </nav>

  <!-- center: feed -->
  <main class="feed">
    <div class="feed-head">
      <h1 data-i18n="homeTitle">الرئيسية</h1>
      <div class="live"><span class="dot"></span> <span data-i18n="liveNow">مباشر الآن</span></div>
    </div>

    <div class="composer">
      <div class="avatar" style="background:linear-gradient(135deg,var(--magenta),var(--amber));">ع</div>
      <div style="flex:1;">
        <textarea id="composeInput" data-i18n-placeholder="composePlaceholder" placeholder="شنو صدى اليوم؟" rows="2" oninput="handleCompose(this)"></textarea>
        <div class="composer-foot">
          <div class="composer-icons">
            <button class="icon-btn" data-i18n-title="imageTitle" title="صورة">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
            </button>
            <button class="icon-btn" data-i18n-title="pollTitle" title="استطلاع">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M12 20V4M20 20v-7"/></svg>
            </button>
            <button class="icon-btn" data-i18n-title="emojiTitle" title="إيموجي">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>
            </button>
          </div>
          <button class="post-submit" id="postBtn" data-i18n="postBtn">نشر</button>
        </div>
      </div>
    </div>

    <div id="postsList"></div>
  </main>

  <!-- left: trends / suggestions -->
  <aside class="side">
    <div class="search-shell">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
      <input type="text" data-i18n-placeholder="searchPlaceholder" placeholder="ابحث في صدى">
    </div>

    <div class="panel">
      <h3 data-i18n="trendingTitle">الأكثر تداولاً</h3>
      <div class="trend"><div class="cat">تقنية · شائع</div><div class="tag">#الذكاء_الاصطناعي</div><div class="vol">١٢.٤ ألف صدى</div></div>
      <div class="trend"><div class="cat">رياضة</div><div class="tag">#كأس_العرب</div><div class="vol">٨.٩ ألف صدى</div></div>
      <div class="trend"><div class="cat">تصميم</div><div class="tag">#واجهات_عربية</div><div class="vol">٣.١ ألف صدى</div></div>
      <a href="#" class="panel-foot-link" data-i18n="showMore">عرض المزيد</a>
    </div>

    <div class="panel">
      <h3 data-i18n="suggestedTitle">حسابات تستحق المتابعة</h3>
      <div class="follow-row">
        <div class="avatar" style="width:38px;height:38px;font-size:13px;background:linear-gradient(135deg,var(--cyan),var(--violet));">س</div>
        <div class="who"><div class="name">سارة</div><div class="handle">‎@sara.codes</div></div>
        <button class="follow-btn" data-i18n="followBtn">متابعة</button>
      </div>
      <div class="follow-row">
        <div class="avatar" style="width:38px;height:38px;font-size:13px;background:linear-gradient(135deg,var(--amber),var(--magenta));">م</div>
        <div class="who"><div class="name">مشاري</div><div class="handle">‎@mishari.ui</div></div>
        <button class="follow-btn" data-i18n="followBtn">متابعة</button>
      </div>
      <a href="#" class="panel-foot-link" data-i18n="showMore">عرض المزيد</a>
    </div>
  </aside>

</div>

<script>
  const posts = [
    {
      name:"نورة القحطاني", handle:"@noura.q", time:"قبل ٣ ساعات",
      avatar:"linear-gradient(135deg,var(--cyan),var(--violet))", initial:"ن",
      text:"أطلقنا اليوم النسخة التجريبية من المنصة 🎉 كل صدى يبدأ بكلمة… شاركونا رأيكم بالتصميم الجديد.",
      media:true, likes:284, replies:32, reposts:41
    },
    {
      name:"فيصل المطيري", handle:"@faisal.m", time:"قبل ٥ ساعات",
      avatar:"linear-gradient(135deg,var(--amber),var(--magenta))", initial:"ف",
      text:"أفضل شي بمنصات التواصل العربية إنها تفهم لهجاتنا واهتماماتنا. صدى فعلاً حس مختلف.",
      media:false, likes:512, replies:58, reposts:97
    },
    {
      name:"هند العتيبي", handle:"@hind.dev", time:"قبل ٨ ساعات",
      avatar:"linear-gradient(135deg,var(--violet),var(--magenta))", initial:"هـ",
      text:"بدأت أتعلم تصميم واجهات عربية RTL هالأسبوع، وتفاجأت كم التفاصيل الصغيرة تفرق. أي مصدر تنصحون فيه؟",
      media:false, likes:96, replies:21, reposts:6
    },
    {
      name:"عبدالرحمن ناصر", handle:"@a.nasser", time:"أمس",
      avatar:"linear-gradient(135deg,var(--cyan),var(--amber))", initial:"ع",
      text:"صباح الخير يا صدى ☀️ شنو أول شي تسوونه كل صباح قبل ما تبدأون يومكم؟",
      media:false, likes:143, replies:64, reposts:12
    }
  ];

  const list = document.getElementById('postsList');

  posts.forEach((p, i) => {
    const el = document.createElement('div');
    el.className = 'post';
    el.style.animationDelay = (i * 0.06) + 's';
    el.innerHTML = `
      <div class="avatar" style="background:${p.avatar};">${p.initial}</div>
      <div class="post-body">
        <div class="post-head">
          <span class="name">${p.name}</span>
          <span class="handle">${p.handle}</span>
          <span class="time">· ${p.time}</span>
        </div>
        <div class="post-text">${p.text}</div>
        ${p.media ? '<div class="post-media">صورة المنشور</div>' : ''}
        <div class="post-actions">
          <button class="action reply">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span class="count">${p.replies}</span>
          </button>
          <button class="action repost" onclick="toggleRepost(this)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m17 2 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
            <span class="count">${p.reposts}</span>
          </button>
          <button class="action like" onclick="toggleLike(this)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
            <span class="count">${p.likes}</span>
            <span class="ripple"><span></span></span>
          </button>
          <button class="action echo" title="صدى">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8"/></svg>
          </button>
        </div>
      </div>
    `;
    list.appendChild(el);
  });

  function toggleLike(btn){
    const liked = btn.classList.toggle('liked');
    const countEl = btn.querySelector('.count');
    let count = parseInt(countEl.textContent, 10);
    countEl.textContent = liked ? count + 1 : count - 1;
    const ripple = btn.querySelector('.ripple');
    ripple.classList.remove('go');
    void ripple.offsetWidth;
    ripple.classList.add('go');
  }

  function toggleRepost(btn){
    const reposted = btn.classList.toggle('reposted');
    const countEl = btn.querySelector('.count');
    let count = parseInt(countEl.textContent, 10);
    countEl.textContent = reposted ? count + 1 : count - 1;
  }

  function handleCompose(el){
    const btn = document.getElementById('postBtn');
    btn.classList.toggle('ready', el.value.trim().length > 0);
  }
</script>
<script src="/assets/i18n.js"></script>
</body>
</html>
