<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

if (empty($_SESSION['pending_pin_user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('noPendingLogin')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$pin = trim($data['pin'] ?? '');
$ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$userId = $_SESSION['pending_pin_user_id'];

if (too_many_attempts($pdo, $ip, "pin_{$userId}", 6, 15)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, name, handle, pin_hash FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user || !password_verify($pin, $user['pin_hash'])) {
    record_attempt($pdo, $ip, "pin_{$userId}");
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('incorrectPin')]);
    exit;
}

unset($_SESSION['pending_pin_user_id']);
session_regenerate_id(true);
$_SESSION['user_id'] = $user['id'];
$_SESSION['name']    = $user['name'];
$_SESSION['handle']  = $user['handle'];

echo json_encode([
    "success" => true,
    "message" => msg('loginSuccess'),
    "user" => ["id" => $user['id'], "name" => $user['name'], "handle" => $user['handle']]
]);
