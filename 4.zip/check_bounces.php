<?php
/**
 * فحص الـ Bounces عن طريق "السؤال" بدل "الانتظار" (Polling بدل Webhook).
 * -----------------------------------------------------------------------
 * ليش هذا الملف موجود؟
 * InfinityFree تحظر أي طلب وارد (Inbound) من خدمة خارجية أوتوماتيكية
 * (Webhook، Cron خارجي، إلخ) بجدار حماية يتطلب جافاسكريبت وكوكيز — وهذا
 * ما يفرقش بين Resend والـ Cloudflare Worker وأي طرف ثالث. بالمقابل،
 * InfinityFree نفسها ألغت خاصية Cron Jobs من عندها من 2023.
 *
 * الحل: هذا الملف يُستدعى بصمت من متصفح الزائر الحقيقي نفسه (عبر سطر
 * جافاسكريبت بسيط بصفحة index.html) — فهو "طلب صادر من متصفح حقيقي
 * ينفّذ جافاسكريبت ويقبل كوكيز"، فما يتحظر إطلاقًا. الملف بدوره يسوي
 * طلب صادر (Outbound) لـ Resend API - وهذا مسموح دائمًا حسب توصية
 * InfinityFree نفسها ("Make outbound requests instead").
 *
 * ملاحظة مهمة: عكس الـ Webhook القديم، الـ API هنا ما يعطينا نوع الـ
 * Bounce بالتفصيل (دائم/مؤقت) — بس يقول "bounced" بشكل عام. لذلك نسجّله
 * دائمًا كـ "Undetermined"، ومنطق الحظر التلقائي الموجود أصلًا بـ
 * config.php (email_bounce_should_block) يتكفّل بمنع البريد لو تكرر
 * فشله 3 مرات فأكثر — نفس الحماية، بس تحتاج تكرار بدل ما تمنع من أول
 * Bounce واحد لو كان مصدره غير مؤكد.
 */
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

// فترة التبريد بين كل فحص والثاني (بالثواني) — عشان ما نضغط على Resend
// API ولا نبطئ الموقع لو فتح 100 زائر الصفحة بنفس الدقيقة.
const POLL_COOLDOWN_SECONDS = 300; // 5 دقائق

try {
    $pdo->beginTransaction();

    $state = $pdo->query("SELECT last_email_id, last_checked_at FROM bounce_poll_state WHERE id = 1 FOR UPDATE")->fetch();

    $now = time();
    $lastChecked = $state && $state['last_checked_at'] ? strtotime($state['last_checked_at'] . ' UTC') : 0;

    if (($now - $lastChecked) < POLL_COOLDOWN_SECONDS) {
        // فحصنا مؤخرًا، ما فيه داعي نسأل Resend الآن.
        $pdo->commit();
        echo json_encode(['success' => true, 'skipped' => true]);
        exit;
    }

    // نحدّث وقت آخر فحص فورًا (قبل ما نكمل) عشان لو فتح كذا زائر بنفس
    // اللحظة بالضبط، بس واحد يسوي الفحص الفعلي.
    $pdo->prepare("UPDATE bounce_poll_state SET last_checked_at = UTC_TIMESTAMP() WHERE id = 1")->execute();
    $pdo->commit();

    $lastEmailId = $state['last_email_id'] ?? null;

    // ---------------------------------------------------------------
    // نسأل Resend عن آخر 50 إيميل مُرسَل (الأحدث أولًا).
    // ---------------------------------------------------------------
    $ch = curl_init('https://api.resend.com/emails?limit=50');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ["Authorization: Bearer {$RESEND_API_KEY}"],
        CURLOPT_TIMEOUT => 15,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || !$response) {
        echo json_encode(['success' => false, 'message' => 'resend api unreachable']);
        exit;
    }

    $body = json_decode($response, true);
    $emails = $body['data'] ?? [];

    $newestIdSeen = $lastEmailId;
    $processed = 0;

    foreach ($emails as $index => $item) {
        $id = $item['id'] ?? null;
        if (!$id) continue;

        // أول عنصر بالقائمة هو الأحدث — نحفظه كعلامة "آخر شي فحصناه".
        if ($index === 0) {
            $newestIdSeen = $id;
        }

        // وصلنا لبريد سبق فحصناه بمرة سابقة؟ نوقف — كل اللي بعده أقدم.
        if ($lastEmailId !== null && $id === $lastEmailId) {
            break;
        }

        if (($item['last_event'] ?? '') === 'bounced') {
            $to = $item['to'][0] ?? null;
            if ($to) {
                email_bounce_record($pdo, $to, 'Bounced (via Resend API polling)', 'Undetermined');
                $processed++;
            }
        }
    }

    if ($newestIdSeen !== $lastEmailId) {
        $update = $pdo->prepare("UPDATE bounce_poll_state SET last_email_id = ? WHERE id = 1");
        $update->execute([$newestIdSeen]);
    }

    echo json_encode(['success' => true, 'processed' => $processed]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    @file_put_contents(__DIR__ . '/error_debug.log',
        "[" . date('Y-m-d H:i:s') . "] check_bounces: " . $e->getMessage() . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['success' => false]);
}
