-- شغّلها مرة وحدة عبر phpMyAdmin (نفس طريقة باقي ملفات migration_*.sql)
-- تخزن حالة الحماية لكل عنوان IP بيحاول ينشئ حسابات: أول 3 محاولات
-- بدون كابتشا، من الرابعة تتفعّل Turnstile، وحظر تصاعدي بعد 10/20/30
-- محاولة (10 دقائق / 30 دقيقة / ساعة). تُستخدم من register.php.
CREATE TABLE IF NOT EXISTS register_security (
    identifier      VARCHAR(190) NOT NULL PRIMARY KEY, -- عنوان IP
    attempt_count   INT NOT NULL DEFAULT 0,
    last_attempt_at DATETIME NOT NULL,
    blocked_until   DATETIME NULL,
    INDEX (last_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
