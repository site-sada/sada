-- شغّل هذا الملف مرة وحدة في phpMyAdmin الخاص بقاعدة بياناتك على InfinityFree

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    -- handle (اسم المستخدم) يُختار يدويًا بخطوة منفصلة بعد التحقق من الكود،
    -- يبقى NULL لحين يختاره المستخدم — الحساب لا يُعتبر مكتملًا إلا بعد
    -- email_verified = 1 وhandle IS NOT NULL معًا (راجع login.php).
    handle VARCHAR(50) NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    birthdate DATE NULL,
    password_hash VARCHAR(255) NOT NULL,
    email_verified TINYINT(1) NOT NULL DEFAULT 0,
    verify_token VARCHAR(64) NULL,
    verify_code VARCHAR(6) NULL,
    verify_code_expires DATETIME NULL,
    pin_hash VARCHAR(255) NULL,
    reset_code VARCHAR(6) NULL,
    reset_code_expires DATETIME NULL,
    reset_code_used TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول تقييد المحاولات (تسجيل الدخول، إعادة تعيين كلمة المرور، إلخ).
-- لازم يتنشأ من هنا (مرة وحدة، من phpMyAdmin) مو من كود PHP وقت التشغيل —
-- استضافة InfinityFree غالبًا تمنع أوامر CREATE TABLE لما تجي من التطبيق
-- مباشرة، فلو الجدول ما كان موجود مسبقًا، فحص التقييد يفشل بصمت ويسمح
-- بإرسال أكواد بلا حدود (بالضبط المشكلة اللي كانت تصير).
CREATE TABLE IF NOT EXISTS login_throttle (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    email VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (ip, created_at), INDEX (email, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
