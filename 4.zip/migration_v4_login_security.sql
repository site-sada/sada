-- شغّلها مرة وحدة عبر phpMyAdmin (نفس طريقة باقي ملفات migration_*.sql)
-- تخزن حالة الحماية لكل بريد إلكتروني: عدد المحاولات الفاشلة، آخر محاولة،
-- ووقت انتهاء الحظر المؤقت إن وجد. تُستخدم من login.php لتفعيل Turnstile
-- بعد 5 محاولات فاشلة، وللحظر التصاعدي بعد 10/20/30 محاولة.
CREATE TABLE IF NOT EXISTS login_security (
    identifier      VARCHAR(190) NOT NULL PRIMARY KEY, -- البريد الإلكتروني (lowercase)
    fail_count      INT NOT NULL DEFAULT 0,
    last_attempt_at DATETIME NOT NULL,
    blocked_until   DATETIME NULL,
    INDEX (last_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
