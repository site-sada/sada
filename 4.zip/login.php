<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$email    = trim($data['email'] ?? '');
$password = $data['password'] ?? '';
$remember = !empty($data['remember']);
$ip       = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('invalidEmailPassword')]);
    exit;
}

// تقييد فعلي بحد أقصى 8 محاولات كل 15 دقيقة، مربوط بالـ IP والبريد (وليس بالجلسة فقط)
if (too_many_attempts($pdo, $ip, $email)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}

// ===== حماية Turnstile + الحظر التصاعدي (مربوطة بالبريد الإلكتروني) =====
$identifier = strtolower($email);
$security   = login_security_get($pdo, $identifier);
$failCount  = $security['fail_count'];
$blockedUntil = $security['blocked_until'];

// المستخدم محظور مؤقتًا حاليًا (بعد 10/20/30 محاولة فاشلة)
if ($blockedUntil !== null && $blockedUntil->getTimestamp() > time()) {
    login_security_touch($pdo, $identifier);
    $remainingMinutes = (int)ceil(($blockedUntil->getTimestamp() - time()) / 60);
    http_response_code(429);
    echo json_encode([
        "success" => false,
        "message" => msg('loginBlockedTemp', ['minutes' => $remainingMinutes])
    ]);
    exit;
}

// من المحاولة السادسة فصاعدًا (fail_count >= 5) لازم Turnstile ناجح قبل فحص كلمة المرور
$needsCaptcha = $failCount >= 5;
if ($needsCaptcha) {
    $turnstileToken = trim((string)($data['cf_turnstile_response'] ?? ''));
    if ($turnstileToken === '' || !turnstile_verify($turnstileToken, $ip)) {
        login_security_touch($pdo, $identifier);
        echo json_encode([
            "success" => false,
            "needs_captcha" => true,
            "message" => msg('captchaFailed')
        ]);
        exit;
    }
}
// ===== نهاية حماية Turnstile =====

try {
    $stmt = $pdo->prepare("SELECT id, name, handle, password_hash, email_verified, pin_hash FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        record_attempt($pdo, $ip, $email);
        $newFailCount = $failCount + 1;
        login_security_record_fail($pdo, $identifier, $newFailCount);
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "message" => msg('wrongCredentials'),
            "needs_captcha" => $newFailCount >= 5 // الكابتشا تبقى ظاهرة حتى ينجح الدخول
        ]);
        exit;
    }

    // كلمة المرور صحيحة => تصفير عداد المحاولات الفاشلة (مستخدم حقيقي)
    login_security_reset($pdo, $identifier);

    // الحساب يُعتبر "مكتمل الإنشاء" فقط إذا تحقق شرطان معًا: البريد مفعّل
    // (email_verified) واسم المستخدم مختار (handle). طلبنا صراحة عدم إعادة
    // فتح خطوة "أدخل الكود" من صفحة تسجيل الدخول أبدًا — لو ناقص أي خطوة،
    // الحساب يُعامل كأنه غير موجود من ناحية تسجيل الدخول: رسالة واضحة فقط
    // تطلب منه إكمال إنشاء الحساب من صفحة التسجيل، بدون أي جلسة تفعيل معلّقة.
    if (!$user['email_verified'] || empty($user['handle'])) {
        unset(
            $_SESSION['user_id'], $_SESSION['name'], $_SESSION['handle'],
            $_SESSION['pending_pin_user_id'], $_SESSION['pending_verify_email'],
            $_SESSION['pending_verify_until'], $_SESSION['pending_code_value']
        );
        http_response_code(403);
        echo json_encode([
            "success" => false,
            "message" => msg('accountNotComplete'),
            "incomplete_account" => true
        ]);
        exit;
    }

    if ($remember) {
        // كوكي دخول تلقائي يمتد لـ 30 يوم (بالإضافة إلى الجلسة)
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        setcookie('remember_email', $email, [
            'expires'  => time() + 60 * 60 * 24 * 30,
            'path'     => '/',
            'secure'   => $isHttps,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    // نمسح أي بريد تفعيل معلّق من محاولة سابقة (لو المستخدم سجّل حساب ولم
    // يفعّله، ثم رجع ودخل بحساب ثاني مفعّل) — يمنع تداخل جلسة الدخول
    // الحالية مع عملية تفعيل قديمة غير مكتملة.
    unset($_SESSION['pending_verify_email'], $_SESSION['pending_verify_until']);

    if (!empty($user['pin_hash'])) {
        // عنده PIN مفعّل — ما نفتح جلسة كاملة إلا بعد التحقق منه
        session_regenerate_id(true);
        $_SESSION['pending_pin_user_id'] = $user['id'];
        echo json_encode(["success" => true, "needs_pin" => true, "message" => msg('enterPinToContinue')]);
        exit;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name']    = $user['name'];
    $_SESSION['handle']  = $user['handle'];

    echo json_encode([
        "success" => true,
        "message" => msg('loginSuccess'),
        "user" => ["id" => $user['id'], "name" => $user['name'], "handle" => $user['handle']]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => msg('loginError')]);
}
