-- شغّل هذا في phpMyAdmin (تبويب SQL) مرة وحدة

ALTER TABLE users
    ADD COLUMN verify_code VARCHAR(6) NULL,
    ADD COLUMN verify_code_expires DATETIME NULL,
    ADD COLUMN pin_hash VARCHAR(255) NULL,
    ADD COLUMN reset_code VARCHAR(6) NULL,
    ADD COLUMN reset_code_expires DATETIME NULL;
