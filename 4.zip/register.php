<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mailer.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$name     = trim($data['name'] ?? '');
// normalize_email: يشيل المسافات ويحوّل اسم النطاق فقط لأحرف صغيرة
// (Gmail.com => gmail.com). هذا التحقق بـ PHP هو الأساس دائمًا، حتى لو
// الواجهة (JS) عملت نفس الشي أو فشلت لأي سبب (جافاسكربت معطّل مثلًا).
$email     = normalize_email($data['email'] ?? '');
$password  = $data['password'] ?? '';
$birthdate = trim($data['birthdate'] ?? '');
$ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ===== حماية Turnstile التدريجية + الحظر التصاعدي (مربوطة بعنوان IP) =====
// أول 3 محاولات بدون كابتشا، من الرابعة تلزم Turnstile.
// ملاحظة مهمة: المحاولة هنا ما تُحسب (تُسجَّل بجدول register_security)
// إلا لما فعليًا نرسل كود التفعيل بالبريد (تحت، بعد نجاح كل التحققات).
// المورد اللي نبيه نحميه هو "إرسال البريد" نفسه — فشل الكابتشا أو خطأ
// بالبيانات (اسم قصير/إيميل غير صحيح/إيميل مكرر) ما يكلّف السيرفر إرسال
// بريد، فما ينفع نحتسبه ضد المستخدم. عداد التحقق من الكود (verify_code.php)
// مستقل تمامًا عن هذا العداد.
$regSecurity     = register_security_get($pdo, $ip);
$attemptCount    = $regSecurity['attempt_count'];
$regBlockedUntil = $regSecurity['blocked_until'];

if ($regBlockedUntil !== null && $regBlockedUntil->getTimestamp() > time()) {
    $remainingMinutes = (int)ceil(($regBlockedUntil->getTimestamp() - time()) / 60);
    http_response_code(429);
    echo json_encode([
        "success" => false,
        "message" => msg('registerBlockedTemp', ['minutes' => $remainingMinutes])
    ]);
    exit;
}

$needsCaptcha = $attemptCount >= 3; // من المحاولة الرابعة فصاعدًا

if ($needsCaptcha) {
    $turnstileToken = trim((string)($data['cf_turnstile_response'] ?? ''));
    if ($turnstileToken === '' || !turnstile_verify($turnstileToken, $ip)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "needs_captcha" => true,
            "message" => msg('captchaFailed')
        ]);
        exit;
    }
}
// ===== نهاية حماية Turnstile (الاحتساب الفعلي يصير لاحقًا عند الإرسال) =====

// ---- تحقق من صحة المدخلات ----
$errors = [];

if (mb_strlen($name) < 2) {
    $errors[] = msg('nameTooShort');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = msg('invalidEmail');
}
if (mb_strlen($password) < 8) {
    $errors[] = msg('passwordMin8');
}

// ---- تحقق من تاريخ الميلاد: صيغة صحيحة، ليس بالمستقبل، وعمر لا يقل عن 13 سنة ----
$birthdateObj = null;
if ($birthdate === '') {
    $errors[] = msg('birthdateRequired');
} else {
    $birthdateObj = DateTime::createFromFormat('Y-m-d', $birthdate);
    $formatErrors = DateTime::getLastErrors();
    if (!$birthdateObj || ($formatErrors && ($formatErrors['warning_count'] > 0 || $formatErrors['error_count'] > 0))) {
        $errors[] = msg('invalidBirthdate');
        $birthdateObj = null;
    } else {
        $today = new DateTime('today');
        if ($birthdateObj > $today) {
            $errors[] = msg('invalidBirthdate');
            $birthdateObj = null;
        } else {
            $age = $today->diff($birthdateObj)->y;
            if ($age < 13) {
                $errors[] = msg('ageTooYoung');
                $birthdateObj = null;
            }
        }
    }
}

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode([
        "success" => false,
        "message" => implode(msg('listSeparator'), $errors),
        "needs_captcha" => $needsCaptcha
    ]);
    exit;
}

// فحص جدول الرسائل المرتدة (email_bounces): لو هذا البريد سبق وارتدّ
// بشكل دائم (بريد غير موجود/غير صالح)، ما نكمل التسجيل ولا نحاول إرسال
// كود تفعيل له إطلاقًا — نفس الرسالة اللي طلبتها بالضبط.
if (email_bounce_is_blocked($pdo, $email)) {
    http_response_code(422);
    echo json_encode([
        "success" => false,
        "message" => msg('emailBounced'),
        "needs_captcha" => $needsCaptcha
    ]);
    exit;
}

try {
    // تأكد إن البريد غير مستخدم من قبل — لكن فقط لو الحساب "مكتمل" فعليًا
    // (بريد مفعّل + اسم مستخدم مختار). لو فيه صف قديم لنفس البريد لكنه
    // ناقص إحدى الخطوتين (تفعيل البريد أو اختيار اسم المستخدم)، ما نعتبره
    // حساب موجود إطلاقًا — بالضبط طلب "اعتبر الحساب ما انشأ لو ما اكتملت
    // كل الخطوات".
    $stmt = $pdo->prepare("SELECT id, email_verified, handle, verify_code, verify_code_expires FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $existing = $stmt->fetch();
    if ($existing) {
        $isComplete = (int)$existing['email_verified'] === 1 && !empty($existing['handle']);
        if ($isComplete) {
            http_response_code(409);
            echo json_encode([
                "success" => false,
                "message" => msg('emailAlreadyRegistered'),
                "needs_captcha" => $needsCaptcha
            ]);
            exit;
        }

        // حساب غير مكتمل من محاولة سابقة. لو عنده أصلًا كود تفعيل لسا
        // ضمن مدة صلاحيته (١٥ دقيقة) — نفس فحص resend_verification.php/
        // forgot_password.php بالضبط — ما نحذفه ولا نولّد كود جديد ولا
        // نبعث إيميل ثاني، فقط نربط الجلسة بنفس الحساب. هذا يخلي صفحة
        // /verify تعرض تنبيه "عندك كود صالح وصلك قبل شوي" (existingCodeNotice)
        // بدل ما يفاجئه كود ثاني كل مرة يرجع فيها لصفحة إنشاء الحساب.
        $hasValidCode = (int)$existing['email_verified'] === 0
            && $existing['verify_code'] && $existing['verify_code_expires']
            && strtotime($existing['verify_code_expires']) > time();

        if ($hasValidCode) {
            unset($_SESSION['user_id'], $_SESSION['name'], $_SESSION['handle'], $_SESSION['pending_pin_user_id']);
            $_SESSION['pending_verify_email'] = $email;
            $_SESSION['pending_verify_until'] = max(
                $_SESSION['pending_verify_until'] ?? 0,
                strtotime($existing['verify_code_expires'])
            );
            // نتعمّد عدم لمس pending_code_value هنا — عشان verify.php
            // يعتبره كود "قديم" فعليًا (مو تو مبعوث بهذا الطلب) ويعرض
            // تنبيه "ما أرسلنا لك كود جديد" بدل رسالة الإرسال العادية.
            unset($_SESSION['pending_code_value']);

            echo json_encode([
                "success" => true,
                "message" => msg('hasValidCodeUseIt'),
                "email" => $email
            ]);
            exit;
        }

        // ما فيه كود صالح (منتهي أو ما انبعث أصلًا) — هنا فعليًا نعتبر
        // الحساب كأنه ما انشأ، فيُحذف قبل إعادة الإنشاء من الصفر بكود جديد.
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$existing['id']]);
    }

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiresAt = date('Y-m-d H:i:s', time() + 15 * 60);
    $birthdateStr = $birthdateObj->format('Y-m-d');

    // handle (اسم المستخدم) يبقى NULL هنا عمدًا — المستخدم يختاره بنفسه
    // بخطوة منفصلة بعد التحقق من الكود، مو مولّد تلقائيًا من الاسم.
    $insert = $pdo->prepare(
        "INSERT INTO users (name, handle, email, birthdate, password_hash, email_verified, verify_code, verify_code_expires)
         VALUES (?, NULL, ?, ?, ?, 0, ?, ?)"
    );
    $insert->execute([$name, $email, $birthdateStr, $passwordHash, $code, $expiresAt]);

    $userId = $pdo->lastInsertId();

    // نمسح أي جلسة دخول سابقة (لو المتصفح كان لسه داخل بحساب قديم) — بدون
    // هذا، صفحة verify.php كانت بتشوف user_id القديم وتوديه مباشرة لـ /feed
    // بدل ما تعرض له كود تفعيل الحساب الجديد.
    unset($_SESSION['user_id'], $_SESSION['name'], $_SESSION['handle'], $_SESSION['pending_pin_user_id']);

    // نربط البريد قيد التفعيل بجلسة المتصفح الحالية — يمنع أي شخص من تعديل
    // الإيميل في رابط صفحة التفعيل والتحقق بدل شخص آخر (انظر نفس الفحص في verify_code.php)
    $_SESSION['pending_verify_email'] = $email;
    $_SESSION['pending_verify_until'] = time() + 15 * 60;
    // ---- إرسال كود التفعيل عبر إيميل احترافي ----
    $emailSent = send_email(
        $email,
        "كود تفعيل حسابك في صدى: {$code}",
        email_template("
            <h2 style='margin:0 0 6px;font-size:19px;'>أهلًا {$name}</h2>
            <p style='color:#5b5d63;font-size:14.5px;line-height:1.8;margin:0 0 24px;'>
                رمز تفعيل حسابك في صدى جاهز، وصالح لمدة ١٥ دقيقة.
            </p>
            <div style='background:#0f0f0f;border-radius:14px;padding:22px;text-align:center;margin-bottom:22px;'>
                <div style='color:#9a9ca3;font-size:11px;font-weight:600;letter-spacing:2px;margin-bottom:10px;'>رمز التفعيل</div>
                <div style='font-size:34px;font-weight:800;letter-spacing:10px;color:#ffffff;font-family:Tahoma,Arial,sans-serif;direction:ltr;'>{$code}</div>
            </div>
            <p style='color:#9a9ca3;font-size:12.5px;line-height:1.8;margin:0;'>
                لو ما طلبت هذا الرمز، تقدر تتجاهل الرسالة بأمان.
            </p>
        ", "رمز تفعيل حسابك في صدى: {$code}")
    );

    // هنا بالضبط تُحسب محاولة إنشاء الحساب — عند إرسال كود التفعيل، وليس
    // بعد ما يدخل المستخدم الكود بنجاح (لهذا فيه verify.php وله عداده
    // المستقل الخاص فيه). هذا يمنع استنزاف مورد إرسال البريد بلا حساب،
    // حتى لو فشل الإرسال نفسه (خطأ SMTP) — المحاولة صارت والمورد استُهلك.
    register_security_record_attempt($pdo, $ip, $attemptCount + 1);

    echo json_encode([
        "success" => true,
        "message" => $emailSent
            ? msg('verificationSent')
            : msg('accountCreatedNoEmail'),
        "email" => $email
    ]);

    // نخزن قيمة الكود المُرسل نفسها (مو مجرد علم يُستهلك مرة وحدة) — تبقى
    // "طازجة" طول ما نفس الكود لسا هو الفعّال بقاعدة البيانات، حتى لو
    // المستخدم حدّث صفحة verify.php عدة مرات بعد التسجيل مباشرة.
    if ($emailSent) {
        $_SESSION['pending_code_value'] = $code;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => msg('registerError')]);
}
