<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

// هذي آخر خطوة بإكمال إنشاء الحساب — لازم يكون مسجّل دخول فعليًا (الجلسة
// اللي فتحها verify_code.php بعد نجاح كود التفعيل)، وإلا ما فيه طريقة
// نعرف لأي مستخدم نثبّت اسم المستخدم هذا.
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('mustLoginFirst')]);
    exit;
}

$userId = (int)$_SESSION['user_id'];
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (too_many_attempts($pdo, $ip, 'username:' . $userId, 20, 15)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}

$username = mb_strtolower(trim((string)($data['username'] ?? '')));

if ($username === '') {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('usernameRequired')]);
    exit;
}
if (!preg_match('/^[a-z0-9_\x{0600}-\x{06FF}]{3,20}$/u', $username)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('usernameInvalidFormat')]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, name, email_verified, handle FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        // الحساب اختفى (مثلاً اتحذف لأنه كان ناقص ثم أُعيد التسجيل من جديد
        // بنفس البريد بمتصفح ثاني) — نطلب منه يبدأ من صفحة تسجيل الدخول.
        unset($_SESSION['user_id'], $_SESSION['name'], $_SESSION['handle']);
        http_response_code(401);
        echo json_encode(["success" => false, "message" => msg('mustLoginFirst')]);
        exit;
    }

    // لازم يكون فعّل بريده أول — خطوة اختيار اسم المستخدم تجي بعدها مباشرة،
    // ما ينفع تُختصر أو تُطلب قبلها.
    if (!$user['email_verified']) {
        http_response_code(403);
        echo json_encode(["success" => false, "message" => msg('mustVerifyFirst')]);
        exit;
    }

    // سبق واختار اسم مستخدم (حسابه مكتمل بالفعل) — طلب مكرر، نعتبره نجاح
    // بدون أي تعديل عشان ما نكسر تجربة ضغطة رجوع/تحديث الصفحة بعد نجاح سابق.
    if (!empty($user['handle'])) {
        echo json_encode(["success" => true, "message" => msg('accountAlreadyComplete')]);
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE handle = ? AND id != ? LIMIT 1");
    $check->execute([$username, $userId]);
    if ($check->fetch()) {
        record_attempt($pdo, $ip, 'username:' . $userId);
        http_response_code(409);
        echo json_encode(["success" => false, "message" => msg('usernameTaken')]);
        exit;
    }

    // هنا يكتمل إنشاء الحساب فعليًا 100%: بريد مفعّل + اسم مستخدم مختار.
    $pdo->prepare("UPDATE users SET handle = ? WHERE id = ?")->execute([$username, $userId]);
    $_SESSION['handle'] = $username;
    $_SESSION['name'] = $user['name'];

    echo json_encode(["success" => true, "message" => msg('usernameSetSuccess')]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => msg('unexpectedError')]);
}
