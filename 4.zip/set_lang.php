<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$lang = $data['lang'] ?? '';

// تحقق سيرفر حقيقي: لا نثق بأي قيمة يرسلها المتصفح إلا لو كانت ضمن القائمة المسموحة
$allowed = ['ar', 'en'];
if (!in_array($lang, $allowed, true)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('unsupportedLang')]);
    exit;
}

setcookie('sada_lang', $lang, [
    'expires'  => time() + 60 * 60 * 24 * 365, // سنة كاملة، يبقى حتى لو خرج من الموقع
    'path'     => '/',
    'samesite' => 'Lax',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => false, // لازم تُقرأ من الـ JS أيضًا عشان تطبّق فورًا بدون تحميل الصفحة
]);

echo json_encode(["success" => true, "lang" => $lang]);
