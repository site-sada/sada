-- شغّلها مرة وحدة عبر phpMyAdmin (نفس طريقة باقي ملفات migration_*.sql)
--
-- تخزن الرسائل المرتدة (Bounces) الواصلة من Resend عبر webhook_resend.php:
-- البريد، سبب الفشل، تاريخ أول/آخر Bounce، وعدد مرات التكرار.
--
-- عمودان إضافيان مهمّان للمنطق (بعدد ما هو مطلوب لكن ضروريان تقنيًا):
--   bounce_type  : نوع الفشل كما يرسله Resend (Permanent / Transient /
--                  Undetermined) — لازم نعرفه عشان نفرّق بين فشل دائم
--                  (بريد غير موجود) وفشل مؤقت (صندوق ممتلئ...) بدل ما
--                  نمنع كل بريد ارتدّ لأي سبب.
--   is_permanent : علم محسوب (0/1) يقول هل نمنع الإرسال لهذا البريد أو
--                  لا — يُحدَّث تلقائيًا من config.php (email_bounce_record)
--                  حسب bounce_type وعدد مرات التكرار، فباقي الكود
--                  (register.php وغيره) يفحصه مباشرة بدون ما يعيد نفس
--                  منطق القرار في كل مكان.
CREATE TABLE IF NOT EXISTS email_bounces (
    email           VARCHAR(190) NOT NULL PRIMARY KEY,
    reason          VARCHAR(255) NULL,
    bounce_type     VARCHAR(20) NULL,
    first_bounce_at DATETIME NOT NULL,
    last_bounce_at  DATETIME NOT NULL,
    bounce_count    INT NOT NULL DEFAULT 1,
    is_permanent    TINYINT(1) NOT NULL DEFAULT 0,
    INDEX (is_permanent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
