<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('mustLoginFirst')]);
    exit;
}
if (empty($_SESSION['handle'])) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('accountNotComplete')]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$pin = trim($data['pin'] ?? '');

if (!preg_match('/^\d{4}$/', $pin)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('pinMustBe4Digits')]);
    exit;
}

$pinHash = password_hash($pin, PASSWORD_BCRYPT);
$pdo->prepare("UPDATE users SET pin_hash = ? WHERE id = ?")->execute([$pinHash, $_SESSION['user_id']]);

echo json_encode(["success" => true, "message" => msg('pinActivated')]);
