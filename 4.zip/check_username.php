<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

// نفس حماية set_username.php: هذا الفحص الفوري متاح فقط لمستخدم مسجّل
// دخول فعليًا (بعد نجاح كود التفعيل)، مو لأي زائر — يمنع استخدامه
// كأداة عامة لسحب/تخمين كل أسماء المستخدمين المتاحة بالموقع بلا قيود.
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('mustLoginFirst')]);
    exit;
}

$username = mb_strtolower(trim((string)($data['username'] ?? '')));

if (!preg_match('/^[a-z0-9_\x{0600}-\x{06FF}]{3,20}$/u', $username)) {
    echo json_encode(["success" => false, "available" => false, "message" => msg('usernameInvalidFormat')]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE handle = ? AND id != ? LIMIT 1");
    $stmt->execute([$username, (int)$_SESSION['user_id']]);
    $taken = (bool)$stmt->fetch();

    echo json_encode([
        "success" => true,
        "available" => !$taken,
        "message" => $taken ? msg('usernameTaken') : msg('usernameAvailable')
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "available" => false, "message" => msg('unexpectedError')]);
}
