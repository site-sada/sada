-- ==========================================================
-- ملف SQL موحّد — شغّله دفعة وحدة في phpMyAdmin (تبويب SQL)
--
-- هذا الإصدار "مضمون" على أي نسخة MySQL/MariaDB (حتى القديمة جدًا)،
-- بعكس النسخة السابقة اللي كانت تعتمد على "ADD COLUMN IF NOT EXISTS"
-- (مدعومة بس من MariaDB 10.0.2+ / MySQL 8.0.29+، واستضافات InfinityFree
-- تختلف نسخها من سيرفر لسيرفر، فما نقدر نضمنها 100%).
--
-- بدل كذا، كل عمود يتفحص أول عبر information_schema.COLUMNS: لو موجود
-- من قبل (سواء شغّلت الميغريشن القديم أو لا) يتجاوزه، ولو ناقص يضيفه.
-- آمن تمامًا تشغّله أكثر من مرة، ولا يلمس أي بيانات موجودة عندك.
-- ==========================================================

-- ---------- جدول المستخدمين (يُنشأ لو ناقص بالكامل) ----------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    handle VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- إضافة أعمدة users الناقصة فقط (فحص فعلي قبل كل إضافة) ----------
SET @db := DATABASE();

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='email_verified') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN email_verified TINYINT(1) NOT NULL DEFAULT 0'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='verify_token') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN verify_token VARCHAR(64) NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='verify_code') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN verify_code VARCHAR(6) NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='verify_code_expires') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN verify_code_expires DATETIME NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='pin_hash') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN pin_hash VARCHAR(255) NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='reset_code') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN reset_code VARCHAR(6) NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='reset_code_expires') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN reset_code_expires DATETIME NULL'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='reset_code_used') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN reset_code_used TINYINT(1) NOT NULL DEFAULT 0'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------- v8: خطوة اختيار اسم المستخدم بعد التفعيل + تاريخ الميلاد ----------
-- handle صار يُختار يدويًا بخطوة منفصلة بعد كود التفعيل، مو مولّد تلقائيًا
-- وقت التسجيل — لازم يُسمح NULL لحين يختاره المستخدم. آمن يشتغل أكثر من
-- مرة (MODIFY COLUMN لا يكسر شي لو كان NULL مسموح أصلًا).
ALTER TABLE users MODIFY COLUMN handle VARCHAR(50) NULL;

SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='birthdate') > 0,
  'SELECT 1',
  'ALTER TABLE users ADD COLUMN birthdate DATE NULL AFTER email'
));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------- جدول تقييد المحاولات ----------
CREATE TABLE IF NOT EXISTS login_throttle (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    email VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (ip, created_at), INDEX (email, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- حماية تسجيل الدخول ----------
CREATE TABLE IF NOT EXISTS login_security (
    identifier      VARCHAR(190) NOT NULL PRIMARY KEY,
    fail_count      INT NOT NULL DEFAULT 0,
    last_attempt_at DATETIME NOT NULL,
    blocked_until   DATETIME NULL,
    INDEX (last_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- حماية إنشاء الحسابات ----------
CREATE TABLE IF NOT EXISTS register_security (
    identifier      VARCHAR(190) NOT NULL PRIMARY KEY,
    attempt_count   INT NOT NULL DEFAULT 0,
    last_attempt_at DATETIME NOT NULL,
    blocked_until   DATETIME NULL,
    INDEX (last_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- الرسائل المرتدة من Resend (Email Bounces) — الجديد ----------
CREATE TABLE IF NOT EXISTS email_bounces (
    email           VARCHAR(190) NOT NULL PRIMARY KEY,
    reason          VARCHAR(255) NULL,
    bounce_type     VARCHAR(20) NULL,
    first_bounce_at DATETIME NOT NULL,
    last_bounce_at  DATETIME NOT NULL,
    bounce_count    INT NOT NULL DEFAULT 1,
    is_permanent    TINYINT(1) NOT NULL DEFAULT 0,
    INDEX (is_permanent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
