-- Migration v8: خطوة "اختيار اسم المستخدم" بعد التفعيل + حقل تاريخ الميلاد
-- شغّل هذا الملف مرة وحدة في phpMyAdmin بعد ما تشغّل بقية ملفات الـ migration.
--
-- 1) اسم المستخدم (handle) صار يُختار يدويًا من المستخدم بخطوة منفصلة بعد
--    التحقق من الكود، مو مولّد تلقائيًا وقت التسجيل — فلازم يصير NULL مسموح
--    بالعمود لحين ما يختار المستخدم واحد. حساب "مكتمل" فعليًا فقط لما
--    email_verified = 1 وhandle IS NOT NULL معًا.
ALTER TABLE users MODIFY COLUMN handle VARCHAR(50) NULL;

-- 2) تاريخ الميلاد — حقل مطلوب بنموذج التسجيل الجديد.
ALTER TABLE users ADD COLUMN birthdate DATE NULL AFTER email;
