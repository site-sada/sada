-- ==========================================================
-- ملف SQL كامل وموحّد لموقع صدى — شغّله مرة وحدة في phpMyAdmin
-- (تبويب SQL) بعد ما تحذف الجداول القديمة.
-- يحتوي كل شي: جدول المستخدمين + جدول تقييد المحاولات.
-- ==========================================================

DROP TABLE IF EXISTS login_throttle;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    handle VARCHAR(50) NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    birthdate DATE NULL,
    password_hash VARCHAR(255) NOT NULL,
    email_verified TINYINT(1) NOT NULL DEFAULT 0,
    verify_token VARCHAR(64) NULL,
    verify_code VARCHAR(6) NULL,
    verify_code_expires DATETIME NULL,
    pin_hash VARCHAR(255) NULL,
    reset_code VARCHAR(6) NULL,
    reset_code_expires DATETIME NULL,
    reset_code_used TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE login_throttle (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    email VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (ip, created_at), INDEX (email, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
