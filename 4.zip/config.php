<?php
// توحيد المنطقة الزمنية مع MySQL (UTC) — بدونها، مقارنة الوقت في
// login_security_get() كانت بتفسّر NOW() بتوقيت خاطئ وتصفّر عداد
// المحاولات الفاشلة كل مرة قبل ما يتزوّد.
date_default_timezone_set('UTC');

/**
 * إعدادات الاتصال بقاعدة البيانات
 * عدّل القيم التالية بمعلومات قاعدة بيانات InfinityFree الخاصة فيك
 * تلقاها في لوحة تحكم InfinityFree > MySQL Databases
 */

$DB_HOST = "sql202.infinityfree.com";   // اسم السيرفر (Hostname)
$DB_NAME = "if0_42530830_abbdda";       // اسم قاعدة البيانات
$DB_USER = "if0_42530830";              // اسم المستخدم
$DB_PASS = "CCBmjxpG7l1n";              // كلمة المرور

/**
 * إعدادات إرسال البريد عبر Resend (HTTPS API — بدون SMTP، يتجاوز حجب البورتات)
 */
$RESEND_API_KEY = "re_fkGwt4bi_HRYFroiq23dqiz1G2eRDcgA4";
$MAIL_FROM      = "noreply@sada.abrdns.com"; // الدومين الموثّق بحساب Resend (وليس دومين الموقع الأساسي)
$MAIL_FROM_NAME = "صدى";
$SITE_URL       = "https://ssddaaff.wuaze.com"; // رابط موقعك الفعلي

// قاموس رسائل النجاح/الخطأ بلغتين (عربي/إنجليزي) — يقرأ اللغة من كوكي sada_lang
require_once __DIR__ . '/messages.php';

/**
 * Cloudflare Turnstile — Secret Key (سرّي، من جهة الخادم فقط، لا يوضع أبدًا
 * بالواجهة/JavaScript). Site Key (العلني) يوضع في login.html فقط.
 * غيّره من لوحة تحكم Cloudflare > Turnstile.
 */
$TURNSTILE_SECRET_KEY = "0x4AAAAAAEB8jJaQ4Ka0bSPsWGl70vGuZ2o";

// شبكة أمان عامة: أي خطأ PHP غير متوقع يرجع JSON صحيح بدل صفحة خطأ خام
// تكسر استدعاءات fetch() بالواجهة وتظهر كـ"تعذر الاتصال بالخادم"
//
// أمان: تفاصيل الخطأ الحقيقية (رسالة الاستثناء + مسار الملف + رقم السطر) ما
// ترجع أبدًا للمتصفح — لأنها تكشف بنية السيرفر والمسارات الداخلية لأي زائر.
// بدل ذلك تُسجَّل بملف خاص على السيرفر فقط (غير قابل للتحميل من الخارج،
// راجع .htaccess) عشان تراجعها وقت الحاجة بدون ما تكون مكشوفة للعموم.
set_exception_handler(function($e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    $log = "[" . date('Y-m-d H:i:s') . "] " . $e->getMessage() . " — " . $e->getFile() . ":" . $e->getLine() . "\n";
    @file_put_contents(__DIR__ . '/error_debug.log', $log, FILE_APPEND);
    echo json_encode([
        "success" => false,
        "message" => msg('unexpectedError')
    ]);
    exit;
});
error_reporting(E_ALL);
ini_set('display_errors', '0'); // الأخطاء تُسجَّل بملف خاص فقط، وما تظهر أبدًا لأي زائر

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5, // يفشل خلال 5 ثواني بدل ما يعلّق دقيقة كاملة لو السيرفر بطيء/معطّل
        ]
    );
} catch (PDOException $e) {
    // نسجّل السبب الحقيقي هنا (قبل كان يفشل بصمت بدون أي أثر بملف log)
    @file_put_contents(__DIR__ . '/error_debug.log',
        "[" . date('Y-m-d H:i:s') . "] DB connect fail: " . $e->getMessage() . "\n",
        FILE_APPEND);
    http_response_code(500);
    die(json_encode(["success" => false, "message" => msg('dbConnectFail')]));
}

// إعدادات الجلسة (Session) — تُستخدم في جميع الصفحات المحمية
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    session_set_cookie_params([
        'lifetime' => 60 * 60 * 24 * 7, // أسبوع
        'path' => '/',
        'httponly' => true,
        'secure' => $isHttps,   // يمنع إرسال كوكي الجلسة عبر اتصال غير مشفّر
        'samesite' => 'Lax',
    ]);
    session_start();
}

/**
 * توليد/التحقق من CSRF token — يمنع مواقع خارجية من إرسال طلبات دخول/تسجيل
 * نيابة عن المستخدم دون علمه
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(?string $token): bool {
    return !empty($_SESSION['csrf_token']) && !empty($token)
        && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * تقييد المحاولات الفعلي عبر قاعدة البيانات (مربوط بعنوان IP + البريد)
 * بعكس عدّاد الجلسة القديم، هذا ما ينحل بمجرد مسح الكوكيز
 */
function too_many_attempts(PDO $pdo, string $ip, string $email, int $maxAttempts = 20, int $windowMinutes = 15): bool {
    // ملاحظة: جدول login_throttle ينشأ من schema.sql (مرة وحدة عبر
    // phpMyAdmin) وليس هنا. محاولة عمل CREATE TABLE وقت التشغيل كانت
    // تفشل بصمت على InfinityFree وتخلي هذا الفحص يرجع "مسموح" دايمًا.
    try {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) c FROM login_throttle
             WHERE (ip = ? OR email = ?) AND created_at > (NOW() - INTERVAL ? MINUTE)"
        );
        $stmt->execute([$ip, $email, $windowMinutes]);
        return (int)$stmt->fetch()['c'] >= $maxAttempts;
    } catch (PDOException $e) {
        // لو فشل فحص التقييد نفسه لأي سبب، ما نوقف الطلب كامل — بس نعتبره
        // غير مقيّد. نسجّل السبب الحقيقي بملف الأخطاء عشان ننتبه له
        // بدل ما يفشل بصمت زي ما صار قبل.
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] too_many_attempts: " . $e->getMessage() . "\n",
            FILE_APPEND);
        return false;
    }
}

function record_attempt(PDO $pdo, string $ip, string $email): void {
    try {
        $stmt = $pdo->prepare("INSERT INTO login_throttle (ip, email) VALUES (?, ?)");
        $stmt->execute([$ip, $email]);
    } catch (PDOException $e) {
        // تسجيل المحاولة غير حرج — نتجاهل الفشل بدل ما نكسر الطلب كامل،
        // بس نسجّل السبب عشان المتابعة.
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] record_attempt: " . $e->getMessage() . "\n",
            FILE_APPEND);
    }
}

/**
 * جدول الانتظار لإرسال كود إعادة تعيين كلمة المرور: أول 3 إرسالات كل
 * وحدة تنتظر 15 دقيقة ثابتة (سواء استُخدم الكود القديم أو لا — الفحص
 * مبني على وقت آخر إرسال فعلي، مو على حالة الكود). بعد 3 محاولات
 * الفترة تتصعّد (30 ثم 60 دقيقة) وتثبت عند حد أقصى ساعتين (120 دقيقة)
 * كحماية إضافية من إساءة الاستخدام/السبام.
 * $priorAttempts = عدد مرات الإرسال المسجّلة قبل هذي المحاولة.
 */
function reset_send_wait_minutes(int $priorAttempts): int {
    $schedule = [0 => 0, 1 => 15, 2 => 15, 3 => 15, 4 => 30, 5 => 60];
    return $schedule[$priorAttempts] ?? 120; // حد أقصى: ساعتين
}

/**
 * يقرر هل مسموح إرسال كود إعادة تعيين جديد الآن أو لا — بالاعتماد على
 * وقت آخر إرسال فعلي (مو هل الكود القديم لسا موجود في العمود)، عشان
 * ما يصير فيه ثغرة: يستخدم المستخدم الكود فينمسح من قاعدة البيانات،
 * ثم يطلب كود جديد فورًا قبل ما تخلص مدة الكود القديم. المحاولات
 * القديمة عمرها أكثر من 24 ساعة تُتجاهل (تعتبر دورة جديدة وترجع العداد للصفر).
 * يرجع: ['allowed' => bool, 'wait_minutes' => int] (المتبقي وقت الرفض)
 */
function reset_send_check(PDO $pdo, string $ip, string $emailKey): array {
    // ملاحظة: جدول login_throttle ينشأ من schema.sql وليس هنا (نفس سبب
    // too_many_attempts أعلاه).
    try {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) c, MAX(created_at) last_at FROM login_throttle
             WHERE (ip = ? OR email = ?) AND created_at > (NOW() - INTERVAL 24 HOUR)"
        );
        $stmt->execute([$ip, $emailKey]);
        $row = $stmt->fetch();
        $priorAttempts = (int)($row['c'] ?? 0);
        $lastAt = $row['last_at'] ?? null;

        if ($priorAttempts === 0 || !$lastAt) {
            return ['allowed' => true, 'wait_minutes' => 0];
        }

        $requiredWait   = reset_send_wait_minutes($priorAttempts);
        $elapsedMinutes = (time() - strtotime($lastAt)) / 60;

        if ($elapsedMinutes >= $requiredWait) {
            return ['allowed' => true, 'wait_minutes' => 0];
        }

        return ['allowed' => false, 'wait_minutes' => (int)ceil($requiredWait - $elapsedMinutes)];
    } catch (PDOException $e) {
        // لو فشل الفحص نفسه، ما نوقف الطلب — بس نعتبره غير مقيّد. نسجّل
        // السبب الحقيقي عشان ننتبه له بدل ما يفشل بصمت زي ما صار قبل.
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] reset_send_check: " . $e->getMessage() . "\n",
            FILE_APPEND);
        return ['allowed' => true, 'wait_minutes' => 0];
    }
}

/**
 * تتحقق من رمز Cloudflare Turnstile عبر واجهة siteverify الرسمية.
 * التحقق الحقيقي دائمًا من جهة الخادم — الواجهة (JS) لا تُعتمد وحدها.
 */
function turnstile_verify(string $token, string $ip): bool {
    global $TURNSTILE_SECRET_KEY;
    if ($token === '' || empty($TURNSTILE_SECRET_KEY)) return false;

    $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_POSTFIELDS     => http_build_query([
            'secret'   => $TURNSTILE_SECRET_KEY,
            'response' => $token,
            'remoteip' => $ip,
        ]),
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($resp === false) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] turnstile_verify curl error: " . $err . "\n", FILE_APPEND);
        return false;
    }
    $result = json_decode($resp, true);
    return !empty($result['success']);
}

/**
 * توحيد صيغة البريد الإلكتروني قبل التحقق والتخزين:
 *  - يشيل المسافات من البداية والنهاية.
 *  - يحوّل اسم النطاق (الجزء بعد @) لأحرف صغيرة فقط (مثل Gmail.com => gmail.com)،
 *    لأن اسم النطاق دائمًا غير حسّاس لحالة الأحرف. اسم المستخدم (قبل @) يبقى
 *    كما هو بدون تعديل لأن بعض مزوّدي البريد يعتبرونه حسّاسًا لحالة الأحرف.
 * هذا التطبيع لا يغيّر شكل البريد الذي يظهر للمستخدم في الواجهة (JS)،
 * فقط يوحّد الصيغة المخزّنة والمُستخدمة فعليًا في التحقق والإرسال.
 */
// يعرض جزء بسيط من البريد فقط (أول حرفين + نجوم + الدومين كامل) بدل
// البريد كامل بصفحة /reset — كافي يذكّر صاحب الحساب الحقيقي إنه بريده هو،
// بدون ما نطبع بريد كامل بالـ HTML لأي شخص يفتح نفس الرابط (شاشة مشتركة،
// سكرين شير، متصفح مو مقفول، إلخ).
function mask_email(string $email): string {
    $parts = explode('@', $email, 2);
    if (count($parts) !== 2 || $parts[0] === '') return $email;
    [$local, $domain] = $parts;
    $visible = mb_substr($local, 0, min(2, mb_strlen($local)));
    return $visible . str_repeat('*', max(3, mb_strlen($local) - mb_strlen($visible))) . '@' . $domain;
}

function normalize_email(string $email): string {
    $email = trim($email);
    $atPos = strrpos($email, '@');
    if ($atPos === false) return $email;
    $local  = substr($email, 0, $atPos);
    $domain = mb_strtolower(substr($email, $atPos + 1));
    return $local . '@' . $domain;
}

/**
 * ===== نظام الرسائل المرتدة (Email Bounces) =====
 * جدول email_bounces (ينشأ من migration_v6_email_bounces.sql) يخزّن أي
 * بريد وصلنا عنه Bounce من Resend عبر webhook_resend.php، مع نوع الفشل
 * (bounce_type: Permanent / Transient / Undetermined). "الحظر" (is_permanent)
 * ينطبق فقط على الأعطال الدائمة (بريد غير موجود/غير صالح)، وليس على
 * الأعطال المؤقتة (صندوق ممتلئ، مشكلة مؤقتة بالخادم) — بالضبط زي ما طلبت.
 */

/** يقرر هل نوع/تكرار هذا الـ Bounce يستدعي منع الإرسال لهذا البريد مستقبلًا */
function email_bounce_should_block(string $bounceType, int $bounceCount): bool {
    // Permanent = فشل دائم مؤكد (بريد غير موجود/غير صالح) => امنع فورًا.
    if ($bounceType === 'Permanent') return true;
    // Undetermined = السبب مو واضح لـ Resend نفسه. حسب توصية Resend: لو
    // تكرر (٣ مرات فأكثر) نعامله كفشل دائم احتياطًا. مرة أو مرتين لا تكفي
    // لمنع بريد قد يكون سليمًا.
    if ($bounceType === 'Undetermined' && $bounceCount >= 3) return true;
    // Transient = عطل مؤقت (صندوق ممتلئ، خادم مستقبل مؤقتًا غير متاح...) => لا نمنع أبدًا.
    return false;
}

/**
 * يسجّل/يحدّث Bounce جديد لبريد معيّن بأمان (Prepared Statements + قفل
 * صف عبر Transaction عشان عدّاد bounce_count ما ينكسر لو وصل أكثر من
 * webhook لنفس البريد بنفس اللحظة تقريبًا).
 */
function email_bounce_record(PDO $pdo, string $email, string $reason, string $bounceType): void {
    $email = mb_strtolower(trim($email));
    if ($email === '') return;

    try {
        $pdo->beginTransaction();

        $select = $pdo->prepare("SELECT bounce_count, is_permanent FROM email_bounces WHERE email = ? FOR UPDATE");
        $select->execute([$email]);
        $row = $select->fetch();

        $newCount = $row ? (int)$row['bounce_count'] + 1 : 1;
        $shouldBlockNow = email_bounce_should_block($bounceType, $newCount) ? 1 : 0;

        if ($row) {
            // GREATEST: مجرد ما يصير الحظر مفعّل مرة، ما نرجّعه false بعدين
            // (Bounce دائم ما يصير فجأة "مو دائم")، حتى لو وصل بعده Bounce مؤقت.
            $update = $pdo->prepare(
                "UPDATE email_bounces
                 SET reason = ?, bounce_type = ?, last_bounce_at = UTC_TIMESTAMP(),
                     bounce_count = ?, is_permanent = GREATEST(is_permanent, ?)
                 WHERE email = ?"
            );
            $update->execute([$reason, $bounceType, $newCount, $shouldBlockNow, $email]);
        } else {
            $insert = $pdo->prepare(
                "INSERT INTO email_bounces (email, reason, bounce_type, first_bounce_at, last_bounce_at, bounce_count, is_permanent)
                 VALUES (?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP(), 1, ?)"
            );
            $insert->execute([$email, $reason, $bounceType, $shouldBlockNow]);
        }

        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] email_bounce_record: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/**
 * يفحص جدول email_bounces قبل إرسال أي كود/رابط لبريد معيّن. يُستخدم في
 * register.php و resend_verification.php و forgot_password.php بالضبط
 * زي ما طلبت — قبل أي إرسال تفعيل/إعادة كود/استعادة كلمة مرور.
 * يرجع true فقط لو البريد مؤكد إنه غير موجود/غير صالح (is_permanent = 1)،
 * وليس لأعطال مؤقتة.
 */
function email_bounce_is_blocked(PDO $pdo, string $email): bool {
    try {
        $stmt = $pdo->prepare("SELECT is_permanent FROM email_bounces WHERE email = ? LIMIT 1");
        $stmt->execute([mb_strtolower(trim($email))]);
        $row = $stmt->fetch();
        return (bool)($row && (int)$row['is_permanent'] === 1);
    } catch (PDOException $e) {
        // نفس فلسفة باقي فحوصات الأمان بهذا الملف: لو فشل الفحص نفسه لأي
        // سبب (الجدول غير موجود بعد، خطأ صلاحيات...)، ما نوقف الإرسال —
        // بس نسجّل السبب عشان ننتبه له.
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] email_bounce_is_blocked: " . $e->getMessage() . "\n", FILE_APPEND);
        return false;
    }
}

/**
 * يجلب حالة الحماية الحالية لبريد معيّن، ويصفّرها تلقائيًا إذا مرّت 30
 * دقيقة بدون أي محاولة دخول (حماية المستخدم الحقيقي من عقاب دائم).
 * يرجع: ['fail_count'=>int, 'blocked_until'=>?DateTime]
 */
function login_security_get(PDO $pdo, string $identifier): array {
    try {
        $stmt = $pdo->prepare("SELECT fail_count, last_attempt_at, blocked_until FROM login_security WHERE identifier = ?");
        $stmt->execute([$identifier]);
        $row = $stmt->fetch();
        if (!$row) return ['fail_count' => 0, 'blocked_until' => null];

        $failCount    = (int)$row['fail_count'];
        $blockedUntil = $row['blocked_until'] ? new DateTime($row['blocked_until'], new DateTimeZone('UTC')) : null;
        $lastAttempt  = $row['last_attempt_at'] ? new DateTime($row['last_attempt_at'], new DateTimeZone('UTC')) : null;

        if ($lastAttempt && (time() - $lastAttempt->getTimestamp()) >= 30 * 60) {
            // 30 دقيقة بدون أي محاولة => تصفير كامل
            $failCount = 0;
            $blockedUntil = null;
        }
        return ['fail_count' => $failCount, 'blocked_until' => $blockedUntil];
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] login_security_get: " . $e->getMessage() . "\n", FILE_APPEND);
        return ['fail_count' => 0, 'blocked_until' => null];
    }
}

/** يسجّل محاولة فاشلة جديدة، ويحدّد الحظر التصاعدي (10=>5د, 20=>30د, 30=>60د) */
function login_security_record_fail(PDO $pdo, string $identifier, int $newFailCount): void {
    $blockedUntil = null;
    if ($newFailCount >= 30)      $blockedUntil = (new DateTime())->modify('+60 minutes')->format('Y-m-d H:i:s');
    elseif ($newFailCount >= 20)  $blockedUntil = (new DateTime())->modify('+30 minutes')->format('Y-m-d H:i:s');
    elseif ($newFailCount >= 10)  $blockedUntil = (new DateTime())->modify('+5 minutes')->format('Y-m-d H:i:s');

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO login_security (identifier, fail_count, last_attempt_at, blocked_until)
             VALUES (?, ?, UTC_TIMESTAMP(), ?)
             ON DUPLICATE KEY UPDATE fail_count = ?, last_attempt_at = UTC_TIMESTAMP(), blocked_until = ?"
        );
        $stmt->execute([$identifier, $newFailCount, $blockedUntil, $newFailCount, $blockedUntil]);
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] login_security_record_fail: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/** يحدّث فقط وقت آخر محاولة (يُستخدم أثناء فترة الحظر أو عند طلب كابتشا) */
function login_security_touch(PDO $pdo, string $identifier): void {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO login_security (identifier, fail_count, last_attempt_at)
             VALUES (?, 0, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE last_attempt_at = UTC_TIMESTAMP()"
        );
        $stmt->execute([$identifier]);
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] login_security_touch: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/** تسجيل دخول ناجح => تصفير العداد بالكامل */
function login_security_reset(PDO $pdo, string $identifier): void {
    try {
        $stmt = $pdo->prepare("DELETE FROM login_security WHERE identifier = ?");
        $stmt->execute([$identifier]);
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] login_security_reset: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/**
 * نفس منطق login_security_get لكن لحماية إنشاء الحسابات (register.php)،
 * ومربوطة بعنوان IP لأن البريد يختلف في كل محاولة تسجيل.
 * يرجع: ['attempt_count'=>int, 'blocked_until'=>?DateTime]
 */
function register_security_get(PDO $pdo, string $identifier): array {
    try {
        $stmt = $pdo->prepare("SELECT attempt_count, last_attempt_at, blocked_until FROM register_security WHERE identifier = ?");
        $stmt->execute([$identifier]);
        $row = $stmt->fetch();
        if (!$row) return ['attempt_count' => 0, 'blocked_until' => null];

        $attemptCount = (int)$row['attempt_count'];
        $blockedUntil = $row['blocked_until'] ? new DateTime($row['blocked_until'], new DateTimeZone('UTC')) : null;
        $lastAttempt  = $row['last_attempt_at'] ? new DateTime($row['last_attempt_at'], new DateTimeZone('UTC')) : null;

        if ($lastAttempt && (time() - $lastAttempt->getTimestamp()) >= 30 * 60) {
            // 30 دقيقة بدون أي محاولة => تصفير كامل
            $attemptCount = 0;
            $blockedUntil = null;
        }
        return ['attempt_count' => $attemptCount, 'blocked_until' => $blockedUntil];
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] register_security_get: " . $e->getMessage() . "\n", FILE_APPEND);
        return ['attempt_count' => 0, 'blocked_until' => null];
    }
}

/** يسجّل محاولة تسجيل حساب جديدة، ويحدّد الحظر التصاعدي (10=>10د, 20=>30د, 30=>60د) */
function register_security_record_attempt(PDO $pdo, string $identifier, int $newAttemptCount): void {
    $blockedUntil = null;
    if ($newAttemptCount >= 30)      $blockedUntil = (new DateTime('now', new DateTimeZone('UTC')))->modify('+60 minutes')->format('Y-m-d H:i:s');
    elseif ($newAttemptCount >= 20)  $blockedUntil = (new DateTime('now', new DateTimeZone('UTC')))->modify('+30 minutes')->format('Y-m-d H:i:s');
    elseif ($newAttemptCount >= 10)  $blockedUntil = (new DateTime('now', new DateTimeZone('UTC')))->modify('+10 minutes')->format('Y-m-d H:i:s');

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO register_security (identifier, attempt_count, last_attempt_at, blocked_until)
             VALUES (?, ?, UTC_TIMESTAMP(), ?)
             ON DUPLICATE KEY UPDATE attempt_count = ?, last_attempt_at = UTC_TIMESTAMP(), blocked_until = ?"
        );
        $stmt->execute([$identifier, $newAttemptCount, $blockedUntil, $newAttemptCount, $blockedUntil]);
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] register_security_record_attempt: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/** تسجيل حساب ناجح => تصفير العداد (مكافأة لصاحب الجهاز، مو عقاب دائم) */
function register_security_reset(PDO $pdo, string $identifier): void {
    try {
        $stmt = $pdo->prepare("DELETE FROM register_security WHERE identifier = ?");
        $stmt->execute([$identifier]);
    } catch (PDOException $e) {
        @file_put_contents(__DIR__ . '/error_debug.log',
            "[" . date('Y-m-d H:i:s') . "] register_security_reset: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}
