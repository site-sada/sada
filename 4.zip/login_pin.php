<?php
require_once __DIR__ . '/config.php';
// لازم يكون فيه عملية دخول معلّقة فعليًا (بعد كلمة المرور الصحيحة) عشان يفتح هالصفحة
if (empty($_SESSION['pending_pin_user_id'])) {
    header('Location: /login');
    exit;
}
$sada_lang = current_lang();
$sada_dir = $sada_lang === 'ar' ? 'rtl' : 'ltr';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($sada_lang) ?>" dir="<?= htmlspecialchars($sada_dir) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<link rel="preload" as="image" href="/assets/logo-black.png" fetchpriority="high">
<meta name="theme-color" content="#0f0f0f">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
<title data-i18n="pinPageTabTitle">رمز PIN — صدى</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#0f0f0f; --ink-soft:#65676b; --ink-faint:#8a8d91; --line:#dbdbdb;
  --bg:#fafafa; --panel:#ffffff; --accent:#1a73e8; --danger:#d93025; --success:#1e7a45;
}
*{box-sizing:border-box;} html,body{height:100%;margin:0;}
body{ font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,sans-serif; background:var(--bg); color:var(--ink); min-height:100vh; display:flex; flex-direction:column; }
a{color:var(--accent);text-decoration:none;} a:hover{text-decoration:underline;} button{font-family:inherit;}
.topbar{ padding:22px 24px; display:flex; align-items:center; justify-content:space-between; }
.topbar-spacer{ width:76px; }
.logo{ display:flex; align-items:center; gap:10px; font-weight:700; font-size:19px; color:var(--ink); }
.logo-mark{ height:29px; width:auto; display:block; flex-shrink:0; }
.lang-switch{ display:flex; align-items:center; gap:6px; border:1px solid var(--line); background:transparent; color:var(--ink-soft); border-radius:20px; padding:7px 14px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit; transition:border-color .15s ease, color .15s ease; }
.lang-switch:hover{ border-color:var(--ink-faint); color:var(--ink); }
.lang-switch svg{ width:15px; height:15px; }
.wrap{ flex:1; display:flex; align-items:center; justify-content:center; padding:16px 16px 60px; }
.card{ width:100%; max-width:380px; background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:36px 32px; }
.below-card{ width:100%; max-width:380px; text-align:center; margin-top:16px; font-size:13.5px; color:var(--ink-soft); }
.stack{ display:flex; flex-direction:column; align-items:center; }
@media (max-width:480px){ .card{ border:none; padding:20px 6px; } }
.card h1{ font-size:20px; font-weight:700; margin:0 0 6px; text-align:center; }
.card .sub{ font-size:13.5px; color:var(--ink-soft); text-align:center; margin:0 0 26px; }
.field{ margin-bottom:14px; }
.field label{ display:block; font-size:13px; font-weight:500; color:var(--ink); margin-bottom:6px; }
.field .input-shell{ border:1px solid var(--line); border-radius:8px; background:#fafafa; }
.field .input-shell:focus-within{ border-color:var(--ink); background:#fff; }
.field .input-shell.field-error{ border-color:var(--danger); }
.field input{ width:100%; border:none; outline:none; background:transparent; padding:12px 14px; font-size:14.5px; font-family:inherit; color:var(--ink); border-radius:8px; }
.btn-primary{ width:100%; border:none; border-radius:8px; padding:12.5px; font-weight:700; font-size:14.5px; color:#fff; background:var(--ink); cursor:pointer; margin-top:6px; }
.btn-primary:hover{ opacity:.88; } .btn-primary[disabled]{ opacity:.5; cursor:default; }
.form-msg{ display:none; font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:16px; text-align:center; }
.form-msg.shake{ animation:sada-shake .35s ease; }
@keyframes sada-shake{
  10%,90%{ transform:translateX(-1px); }
  20%,80%{ transform:translateX(2px); }
  30%,50%,70%{ transform:translateX(-4px); }
  40%,60%{ transform:translateX(4px); }
}
.form-msg.show{ display:block; } .form-msg.error{ background:#fdecea; color:var(--danger); } .form-msg.success{ background:#e9f7ef; color:var(--success); }
footer{ text-align:center; padding:18px; font-size:12px; color:var(--ink-faint); }
</style>
</head>
<body>
  <div class="topbar">
    <div class="topbar-spacer"></div>
    <a href="/" class="logo">
      <span data-i18n="brand">صدى</span>
      <img src="/assets/logo-black.png" alt="" class="logo-mark" width="30" height="29" loading="eager" fetchpriority="high" decoding="async">
    </a>
    <button class="lang-switch" id="langBtn" type="button">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>
      <span id="langBtnLabel">EN</span>
    </button>
  </div>

  <div class="wrap">
    <div class="stack">
      <form class="card" id="pinForm">
        <h1 data-i18n="loginPinTitle">أدخل رمز PIN</h1>
        <p class="sub" data-i18n="loginPinSub">حسابك محمي برمز إضافي — أدخله لإكمال تسجيل دخولك</p>

        <div class="form-msg" id="formMsg"></div>

        <div class="field">
          <label for="pin" data-i18n="pinLabel">رمز PIN</label>
          <div class="input-shell"><input id="pin" name="pin" type="password" inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="••••" required style="letter-spacing:14px;font-size:20px;text-align:center;font-family:monospace;"></div>
        </div>

        <button class="btn-primary" type="submit" id="submitBtn"><span id="submitLabel" data-i18n="loginPinConfirmBtn">تأكيد الدخول</span></button>
      </form>

      <div class="below-card"><span data-i18n="loginPinNotYou">مو أنت؟</span> <a href="/login" data-i18n="backToLogin">رجوع لتسجيل الدخول</a></div>
    </div>
  </div>

  <footer data-i18n="footer">© صدى — جميع الحقوق محفوظة</footer>

  <script>
    window.addEventListener('pageshow', function(e){ if (e.persisted) { window.location.reload(); } });
    const form = document.getElementById('pinForm');
    const msg = document.getElementById('formMsg');
    const submitBtn = document.getElementById('submitBtn');
    const submitLabel = document.getElementById('submitLabel');
    const pinShell = document.getElementById('pin').closest('.input-shell');
    let csrfToken = '';
    fetch('/csrf_token.php').then(r => r.json()).then(d => csrfToken = d.token);

    let lastErrorVibrateAt = 0;
    function vibrateOnError(){
      const now = Date.now();
      if (now - lastErrorVibrateAt < 1500) return; // تجاهل الأخطاء المتكررة بسرعة عشان ما يصير اهتزاز مزعج متواصل
      lastErrorVibrateAt = now;
      if ('vibrate' in navigator) { try { navigator.vibrate(200); } catch (e) {} }
      msg.classList.remove('shake'); void msg.offsetWidth; msg.classList.add('shake');
    }
    function showMsg(text, type){ msg.textContent = text; msg.className = 'form-msg show ' + type; if (type === 'error') vibrateOnError(); }
    document.getElementById('pin').addEventListener('input', function(){
      this.value = this.value.replace(/\D/g, '').slice(0, 4);
      pinShell.classList.remove('field-error');
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.className = 'form-msg';
      pinShell.classList.remove('field-error');
      const pin = document.getElementById('pin').value;
      if (pin.length !== 4) { showMsg(SadaI18n.t('errPinLength'), 'error'); pinShell.classList.add('field-error'); return; }

      submitBtn.disabled = true; submitLabel.textContent = SadaI18n.t('loginPinChecking');

      try {
        const res = await fetch('/verify_login_pin.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin, csrf_token: csrfToken })
        });
        const data = await res.json();

        if (data.success) {
          showMsg(data.message, 'success');
          setTimeout(() => window.location.href = '/feed', 800);
        } else {
          pinShell.classList.add('field-error');
          showMsg(data.message, 'error');
          submitBtn.disabled = false; submitLabel.textContent = SadaI18n.t('loginPinConfirmBtn');
        }
      } catch (err) {
        showMsg(SadaI18n.t('networkError'), 'error');
        submitBtn.disabled = false; submitLabel.textContent = SadaI18n.t('loginPinConfirmBtn');
      }
    });
  </script>
  <script src="/assets/i18n.js"></script>
</body>
</html>
