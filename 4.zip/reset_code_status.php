<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

// نفس فكرة verify.php بالضبط، بس لصفحة إعادة تعيين كلمة المرور: هذا
// الإندبوينت يقول لصفحة reset.html وش الرسالة الصح تعرضها فور ما تفتح —
// "أرسلنا كود جديد" أو "ما أرسلنا كود جديد، عندك كود صالح استخدمه" —
// حسب الوضع الفعلي، مو رسالة ثابتة.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

// هوية صاحب طلب إعادة التعيين تجي من جلسة السيرفر فقط (ضبطها
// forgot_password.php)، أبدًا مو من أي حقل يبعثه المتصفح — عشان ما
// فيه أي قيمة بالطلب يقدر زائر يعدّلها ليشوف حالة/بريد حساب غير حسابه.
$pendingUserId = $_SESSION['pending_reset_user_id'] ?? null;

$hasValidCode = false;
$dbCode = null;
$remainingMinutes = 0;
$codeAlreadyUsed = false;
$maskedEmail = null;
if ($pendingUserId !== null) {
    try {
        $stmt = $pdo->prepare("SELECT email, reset_code, reset_code_expires, reset_code_used FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$pendingUserId]);
        $row = $stmt->fetch();
        if ($row) {
            $maskedEmail = mask_email($row['email']);
        }
        $hasValidCode = $row && $row['reset_code'] && $row['reset_code_expires']
            && strtotime($row['reset_code_expires']) > time();
        $dbCode = $row['reset_code'] ?? null;
        $codeAlreadyUsed = $hasValidCode && !empty($row['reset_code_used']);
        if ($hasValidCode) {
            // نحسب الدقائق المتبقية فعليًا من وقت انتهاء الكود، مو رقم ثابت —
            // عشان الرسالة اللي تنعرض للمستخدم تعكس الوضع الحقيقي كل مرة يفتح
            // فيها الصفحة (حتى لو حدّثها عدة مرات).
            $remainingMinutes = (int)ceil((strtotime($row['reset_code_expires']) - time()) / 60);
        }
    } catch (PDOException $e) {
        $hasValidCode = false;
    }
}

// نقارن الكود الحالي بقاعدة البيانات بآخر كود عرفنا إننا بعثناه بهذه
// الجلسة (مخزّن كقيمة بـ pending_reset_code_value، مو كعلم يُستهلك مرة
// وحدة). طالما نفس الكود لسا موجود، يفضل "طازج" حتى لو المستخدم حدّث
// صفحة /reset عدة مرات — يصير "قديم" فقط لما يتغيّر الكود فعليًا.
$justSentNewCode = isset($_SESSION['pending_reset_code_value'], $dbCode)
    && hash_equals((string)$_SESSION['pending_reset_code_value'], (string)$dbCode);

// لو الكود لتوّه انبعث (بهذا الطلب أو بأي طلب سابق من نفس عملية الإرسال)،
// ما نعرض رسالة "ما أرسلنا كود جديد" — نعرضها فقط لما يكون فيه كود صالح
// قديم فعليًا.
$showOldCodeNotice = $hasValidCode && !$justSentNewCode;

echo json_encode([
    "success" => true,
    "maskedEmail" => $maskedEmail,
    "showOldCodeNotice" => $showOldCodeNotice,
    "remainingMinutes" => $showOldCodeNotice ? $remainingMinutes : 0,
    "codeAlreadyUsed" => $showOldCodeNotice && $codeAlreadyUsed,
]);
