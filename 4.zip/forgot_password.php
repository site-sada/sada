<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mailer.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

$email = normalize_email($data['email'] ?? '');
$ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('invalidEmail')]);
    exit;
}

// فحص جدول الرسائل المرتدة قبل أي محاولة إرسال كود استعادة كلمة المرور —
// لو البريد مسجّل كبريد غير صالح (Bounce دائم)، لا نرسل شي.
if (email_bounce_is_blocked($pdo, $email)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('emailBounced')]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, name, email_verified, reset_code, reset_code_expires, reset_code_used FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

// المستخدم طلب صراحةً رفض الإيميلات غير المسجّلة بدل الرسالة العامة.
// تنويه: هذا يكشف للمهاجم أي الإيميلات مسجّلة في الموقع (User Enumeration)،
// وهو تنازل أمني مقصود بناءً على طلبك.
if (!$user) {
    http_response_code(404);
    echo json_encode(["success" => false, "message" => msg('noAccountWithEmail')]);
    exit;
}

// الحساب موجود بس ما فعّل بريده بعد — نفس منطق login.php بالضبط.
// ما نرسل كود إعادة تعيين لحساب غير مفعّل، ونوضح له إنه يفعّل بريده أول
// بدل ما نتصرف كأن الإيميل مو مسجّل أصلًا.
if (!$user['email_verified']) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('mustVerifyEmail')]);
    exit;
}

// أهم فحص (زي resend_verification.php بالظبط): هل عنده أصلًا كود إعادة
// تعيين لسا ضمن مدة صلاحيته (١٥ دقيقة)؟ لو نعم، ما نولّد ولا نرسل كود
// جديد أبدًا — هذا فحص مستقل تمامًا عن جدول login_throttle، فحتى لو
// فشل ذاك الجدول لأي سبب (غير موجود، خطأ صلاحيات، إلخ)، هذا الفحص لوحده
// يمنع إرسال كود جديد طالما القديم لسا صالح. هذي كانت الثغرة الحقيقية.
$hasValidCode = $user['reset_code'] && $user['reset_code_expires']
    && strtotime($user['reset_code_expires']) > time();

if ($hasValidCode) {
    // نخزّن هوية صاحب طلب إعادة التعيين بجلسة PHP نفسها (كوكي المتصفح)
    // بدل أي باراميتر بالرابط — صفحة /reset ما تاخذ ولا توكن ولا إيميل
    // بمسارها إطلاقًا، فما فيه شي يقدر أي زائر يعدّله بالـ URL أصلًا.
    $_SESSION['pending_reset_user_id'] = $user['id'];
    $remainingMinutes = (int)ceil((strtotime($user['reset_code_expires']) - time()) / 60);

    // الكود لسا داخل نافذة الـ ١٥ دقيقة، بس سبق استخدامه لتغيير كلمة
    // المرور مرة. ما نقوله "استخدم نفسه" (لأنه ما راح يشتغل ثانية) —
    // نوضح له إنه لازم ينتظر لين تنتهي مدة الكود القديم قبل ما نقدر
    // نرسل له كود جديد.
    if (!empty($user['reset_code_used'])) {
        echo json_encode([
            "success" => true,
            "message" => msg('mustWaitAfterUsedCode', ['minutes' => $remainingMinutes]),
            "hasValidCode" => true,
            "codeAlreadyUsed" => true,
            "remainingMinutes" => $remainingMinutes,
        ]);
        exit;
    }

    echo json_encode([
        "success" => true,
        "message" => msg('redirectingToExistingCode', ['minutes' => $remainingMinutes]),
        "hasValidCode" => true,
        "remainingMinutes" => $remainingMinutes,
    ]);
    exit;
}

// ما فيه كود صالح — هذا فعليًا طلب توليد وإرسال كود جديد، فنطبّق حد
// المحاولات هنا (طبقة حماية ثانية، تعتمد على جدول login_throttle، ضد
// السبام على المدى الطويل بعد ما تنتهي صلاحية كل كود).
$resetCheck = reset_send_check($pdo, $ip, "reset_{$email}");
if (!$resetCheck['allowed']) {
    http_response_code(429);
    echo json_encode([
        "success" => false,
        "message" => msg('resetWaitBeforeResend', ['minutes' => $resetCheck['wait_minutes']]),
        "waitMinutes" => $resetCheck['wait_minutes'],
    ]);
    exit;
}
record_attempt($pdo, $ip, "reset_{$email}");

$code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$expiresAt = date('Y-m-d H:i:s', time() + 15 * 60);
$pdo->prepare(
    "UPDATE users SET reset_code = ?, reset_code_expires = ?, reset_code_used = 0 WHERE id = ?"
)->execute([$code, $expiresAt, $user['id']]);

// نخزّن قيمة الكود نفسه بالجلسة (مو علم يُستهلك مرة وحدة) — نفس أسلوب
// verify.php بالضبط. طالما نفس الكود لسا موجود بقاعدة البيانات، يفضل
// يعتبر "طازج" حتى لو المستخدم حدّث صفحة /reset عدة مرات. يصير "قديم"
// بس لما يتغيّر الكود فعليًا (طلب جديد) أو يُستخدم/تنتهي صلاحيته.
$_SESSION['pending_reset_code_value'] = $code;
// هوية صاحب طلب إعادة التعيين تُحفظ بجلسة السيرفر فقط — صفحة /reset ما
// تستقبل أي باراميتر بمسارها (لا إيميل ولا توكن) أصلًا.
$_SESSION['pending_reset_user_id'] = $user['id'];

echo json_encode([
    "success" => true,
    "message" => msg('resetCodeSent'),
]);

// نرجّع الرد للمتصفح فورًا بدل ما نخلّيه معلّق ينتظر رد Resend API (اللي
// ممكن ياخذ ثانية أو ثانيتين، وأحيانًا أكثر). هذا هو سبب "تأخر السيرفر"
// اللي كان يحسّه المستخدم — الطلب كان يكمل بس بعد ما يوصل رد الإيميل.
// إرسال الإيميل نفسه يصير بعد إغلاق الاتصال مع المتصفح، فما يأثر على سرعة الاستجابة.
session_write_close();
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
} else {
    ignore_user_abort(true);
    while (ob_get_level() > 0) { ob_end_flush(); }
    flush();
}

send_email(
    $email,
    "كود إعادة تعيين كلمة المرور: {$code}",
    email_template("
        <h2 style='margin:0 0 6px;font-size:19px;'>مرحبًا {$user['name']}</h2>
        <p style='color:#5b5d63;font-size:14.5px;line-height:1.8;margin:0 0 24px;'>
            وصلنا طلب لإعادة تعيين كلمة مرور حسابك في صدى. استخدم الرمز التالي، صالح لمدة ١٥ دقيقة.
        </p>
        <div style='background:#0f0f0f;border-radius:14px;padding:22px;text-align:center;margin-bottom:22px;'>
            <div style='color:#9a9ca3;font-size:11px;font-weight:600;letter-spacing:2px;margin-bottom:10px;'>رمز إعادة التعيين</div>
            <div style='font-size:34px;font-weight:800;letter-spacing:10px;color:#ffffff;font-family:Tahoma,Arial,sans-serif;direction:ltr;'>{$code}</div>
        </div>
        <p style='color:#9a9ca3;font-size:12.5px;line-height:1.8;margin:0;'>
            لو ما طلبت تغيير كلمة المرور، تجاهل هذي الرسالة — حسابك بأمان.
        </p>
    ", "رمز إعادة تعيين كلمة المرور: {$code}")
);
