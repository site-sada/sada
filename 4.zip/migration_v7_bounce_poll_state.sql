-- شغّلها مرة وحدة عبر phpMyAdmin (نفس طريقة باقي ملفات migration_*.sql)
--
-- جدول صغير (صف واحد دائمًا) يحفظ حالة آخر فحص لـ check_bounces.php:
--   last_checked_at : آخر وقت اتفحصت فيه Resend API — نستخدمه كـ "تبريد"
--                      (Cooldown) عشان ما نسأل Resend كل ما زائر يفتح
--                      الصفحة، بس كل عدة دقائق كحد أقصى.
--   last_email_id   : آخر ID بريد فحصناه فعلًا — عشان ما نعيد معالجة
--                      نفس الـ Bounce مرتين في كل فحص.
CREATE TABLE IF NOT EXISTS bounce_poll_state (
    id              TINYINT NOT NULL PRIMARY KEY DEFAULT 1,
    last_email_id   VARCHAR(64) NULL,
    last_checked_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO bounce_poll_state (id, last_email_id, last_checked_at) VALUES (1, NULL, NULL);
