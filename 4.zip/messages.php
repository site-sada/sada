<?php
/**
 * قاموس رسائل الـ API (نجاح/خطأ) بلغتين — يشتغل بنفس منطق assets/i18n.js
 * حتى لا تختلف لغة رسائل السيرفر عن لغة الواجهة المختارة.
 * اللغة تُقرأ من كوكي sada_lang (نفس الكوكي اللي يضبطه set_lang.php والـ JS).
 */

/**
 * يقرأ لغة الجهاز/النظام من رأس Accept-Language اللي يرسله المتصفح تلقائيًا
 * (نفس اللغة المضبوطة بإعدادات نظام تشغيل المستخدم أو المتصفح) — هذا فحص
 * حقيقي على مستوى السيرفر، مش تخمين. مدعومة عربي/إنجليزي فقط حاليًا.
 */
function detect_browser_lang(): string {
    $header = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    if ($header === '') return 'ar';
    foreach (explode(',', $header) as $part) {
        $code = strtolower(trim(explode(';', $part)[0]));
        if (strpos($code, 'ar') === 0) return 'ar';
        if (strpos($code, 'en') === 0) return 'en';
    }
    return 'ar';
}

function current_lang(): string {
    $cookie = $_COOKIE['sada_lang'] ?? '';
    if (in_array($cookie, ['ar', 'en'], true)) return $cookie;

    // ما فيه تفضيل محفوظ بعد (أول زيارة) — نعتمد على لغة نظام المستخدم
    // ونثبّتها بكوكيز عشان تصير هي الافتراضية بباقي الصفحات فورًا،
    // مع بقاء زر تبديل اللغة بالواجهة يقدر يغيّرها يدويًا في أي وقت.
    $detected = detect_browser_lang();
    if (!headers_sent()) {
        setcookie('sada_lang', $detected, [
            'expires'  => time() + 60 * 60 * 24 * 365,
            'path'     => '/',
            'samesite' => 'Lax',
            'secure'   => !empty($_SERVER['HTTPS']),
            'httponly' => false,
        ]);
    }
    return $detected;
}

/**
 * صياغة عدد الدقائق بصيغة عربية سليمة (مفرد/مثنى/جمع) بدل ما نلصق
 * الرقم قبل كلمة "دقيقة" دايمًا بشكل خاطئ نحويًا.
 */
function ar_minutes_phrase(int $n): string {
    if ($n <= 0) return 'أقل من دقيقة';
    if ($n === 1) return 'دقيقة واحدة';
    if ($n === 2) return 'دقيقتين';
    if ($n >= 3 && $n <= 10) return $n . ' دقائق';
    return $n . ' دقيقة';
}

function en_minutes_phrase(int $n): string {
    if ($n <= 0) return 'less than a minute';
    return $n . ' ' . ($n === 1 ? 'minute' : 'minutes');
}

function msg(string $key, array $vars = []): string {
    static $dict = [
        'ar' => [
            'methodNotAllowed'        => 'طريقة غير مسموحة',
            'sessionExpired'          => 'انتهت صلاحية الجلسة، أعد تحميل الصفحة',
            'invalidEmailPassword'    => 'يرجى إدخال بريد إلكتروني وكلمة مرور صحيحة',
            'tooManyAttempts15'       => 'محاولات كثيرة جدًا، حاول بعد ١٥ دقيقة',
            'tooManyAttemptsShort'    => 'محاولات كثيرة جدًا، حاول بعد قليل',
            'wrongCredentials'        => 'البريد الإلكتروني أو كلمة المرور غير صحيحة',
            'mustVerifyEmail'         => 'لازم تفعّل بريدك الإلكتروني أول — تفقد صندوق الوارد',
            'captchaFailed'           => 'تعذّر التحقق الأمني، حدّث الصفحة وحاول مرة أخرى',
            'loginBlockedTemp'        => 'محاولات كثيرة جدًا، تم إيقاف تسجيل الدخول مؤقتًا. حاول بعد {minutes}',
            'enterPinToContinue'      => 'أدخل رمز PIN لإكمال الدخول',
            'loginSuccess'            => 'تم تسجيل الدخول بنجاح',
            'loginError'              => 'حدث خطأ أثناء تسجيل الدخول',
            'invalidEmail'            => 'بريد إلكتروني غير صحيح',
            'emailBounced'            => 'تأكد من صحة البريد الإلكتروني ثم جرّب مرة ثانية.',
            'retryShortly'            => 'محاولات كثيرة جدًا، حاول بعد قليل',
            'hasValidCodeUseIt'       => 'عندك كود تفعيل صالح وصلك قبل شوي، استخدم نفسه',
            'redirectingToExistingCode' => 'عندك كود إعادة تعيين صالح وصلك قبل شوي، ينتهي خلال {minutes} — استخدم نفسه',
            'mustWaitAfterUsedCode'   => 'سبق واستخدمت الكود اللي وصلك لتغيير كلمة المرور. لازم تنتظر {minutes} قبل ما نقدر نرسل لك كود جديد',
            'codeAlreadyUsed'         => 'هذا الكود سبق استخدامه لتغيير كلمة المرور. انتظر {minutes} ثم اطلب كود جديد',
            'noAccountWithEmail'      => 'ما فيه حساب مسجّل بهذا البريد الإلكتروني',
            'resetCodeSent'           => 'وصلنا كود إعادة تعيين لبريدك',
            'resetWaitBeforeResend'   => 'طلبت كود قبل قليل. حاول مرة أخرى بعد {minutes}',
            'invalidData'             => 'بيانات غير صحيحة',
            'passwordMin8'            => 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
            'noResetRequestForEmail'  => 'ما فيه طلب إعادة تعيين بهذا البريد',
            'invalidOrExpiredLink'    => 'رابط إعادة التعيين غير صالح أو منتهي، اطلب رابطًا جديدًا',
            'codeExpired'             => 'انتهت صلاحية الكود، اطلب كود جديد',
            'incorrectCode'           => 'الكود غير صحيح',
            'newPasswordMustDiffer'   => 'كلمة المرور الجديدة يجب أن تختلف عن كلمة المرور الحالية',
            'passwordChanged'         => 'تم تغيير كلمة المرور بنجاح، سجّل دخولك الآن',
            'nameTooShort'            => 'الاسم قصير جدًا',
            'emailAlreadyRegistered'  => 'هذا البريد الإلكتروني مسجل مسبقًا',
            'verificationSent'        => 'أرسلنا كود التفعيل لبريدك — تفقد صندوق الوارد',
            'accountCreatedNoEmail'   => 'تم إنشاء الحساب، لكن تعذر إرسال كود التفعيل — تواصل معنا',
            'registerError'           => 'حدث خطأ أثناء إنشاء الحساب',
            'registerBlockedTemp'     => 'محاولات إنشاء حساب كثيرة جدًا من هذا الجهاز. حاول بعد {minutes}',
            'enterCode6'              => 'أدخل الكود المكوّن من 6 أرقام',
            'noVerifyRequestForEmail' => 'ما فيه طلب تفعيل بهذا البريد',
            'accountActivated'        => 'تم تفعيل حسابك بنجاح',
            'noPendingLogin'          => 'ما فيه عملية دخول معلّقة، سجّل دخولك من جديد',
            'incorrectPin'            => 'رمز PIN غير صحيح',
            'mustLoginFirst'          => 'لازم تسجل دخول أول',
            'pinMustBe4Digits'        => 'الرمز لازم يكون 4 أرقام بالضبط',
            'pinActivated'            => 'تم تفعيل رمز PIN بنجاح',
            'resendGeneric'           => 'لو الحساب موجود، وصلنا كود تفعيل جديد لبريدك',
            'unsupportedLang'         => 'لغة غير مدعومة',
            'unexpectedError'         => 'حدث خطأ غير متوقع',
            'dbConnectFail'           => 'تعذر الاتصال بقاعدة البيانات',
            'listSeparator'           => '، ',
            'birthdateRequired'       => 'أدخل تاريخ ميلادك',
            'invalidBirthdate'        => 'تاريخ الميلاد غير صحيح',
            'ageTooYoung'             => 'يجب أن يكون عمرك 13 سنة على الأقل لإنشاء حساب',
            'accountNotComplete'      => 'لم تكتمل عملية إنشاء الحساب. يرجى إكمال إنشاء الحساب أولًا قبل تسجيل الدخول',
            'usernameRequired'        => 'أدخل اسم المستخدم',
            'usernameInvalidFormat'   => 'اسم المستخدم يجب أن يكون بين 3 و20 حرفًا، وأحرف/أرقام/شرطة سفلية فقط',
            'usernameTaken'           => 'اسم المستخدم هذا محجوز، جرّب اسمًا آخر',
            'usernameAvailable'       => 'اسم المستخدم متاح',
            'usernameSetSuccess'      => 'تم اختيار اسم المستخدم بنجاح',
            'mustVerifyFirst'         => 'يجب تفعيل بريدك الإلكتروني أولًا',
            'accountAlreadyComplete'  => 'حسابك مكتمل بالفعل',
        ],
        'en' => [
            'methodNotAllowed'        => 'Method not allowed',
            'sessionExpired'          => 'Your session has expired, please reload the page',
            'invalidEmailPassword'    => 'Please enter a valid email and password',
            'tooManyAttempts15'       => 'Too many attempts, try again after 15 minutes',
            'tooManyAttemptsShort'    => 'Too many attempts, try again shortly',
            'wrongCredentials'        => 'Incorrect email or password',
            'mustVerifyEmail'         => 'You need to verify your email first — check your inbox',
            'captchaFailed'           => 'Security verification failed, please refresh the page and try again',
            'loginBlockedTemp'        => 'Too many attempts. Login has been temporarily blocked. Try again in {minutes}',
            'enterPinToContinue'      => 'Enter your PIN to complete login',
            'loginSuccess'            => 'Logged in successfully',
            'loginError'              => 'An error occurred while logging in',
            'invalidEmail'            => 'Invalid email address',
            'emailBounced'            => 'Please make sure your email address is correct, then try again.',
            'retryShortly'            => 'Too many attempts, try again shortly',
            'hasValidCodeUseIt'       => 'You already have a valid activation code from earlier — use that one',
            'redirectingToExistingCode' => 'You already have a valid reset code from earlier, expiring in {minutes} — use that one',
            'mustWaitAfterUsedCode'   => 'You already used your reset code to change your password. Please wait {minutes} before we can send you a new one',
            'codeAlreadyUsed'         => 'This code was already used to change your password. Wait {minutes} then request a new one',
            'noAccountWithEmail'      => 'No account registered with this email',
            'resetCodeSent'           => "We've sent a reset code to your email",
            'resetWaitBeforeResend'   => "You already requested a code recently. Try again in {minutes}.",
            'invalidData'             => 'Invalid data',
            'passwordMin8'            => 'Password must be at least 8 characters',
            'noResetRequestForEmail'  => 'No reset request found for this email',
            'invalidOrExpiredLink'    => 'This reset link is invalid or expired, request a new one',
            'codeExpired'             => 'Code expired, request a new one',
            'incorrectCode'           => 'Incorrect code',
            'newPasswordMustDiffer'   => 'New password must be different from your current password',
            'passwordChanged'         => 'Password changed successfully, log in now',
            'nameTooShort'            => 'Name is too short',
            'emailAlreadyRegistered'  => 'This email is already registered',
            'verificationSent'        => "We've sent an activation code to your email — check your inbox",
            'accountCreatedNoEmail'   => "Account created, but we couldn't send the activation code — contact us",
            'registerError'           => 'An error occurred while creating your account',
            'registerBlockedTemp'     => 'Too many account creation attempts from this device. Try again in {minutes}',
            'enterCode6'              => 'Enter the 6-digit code',
            'noVerifyRequestForEmail' => 'No activation request found for this email',
            'accountActivated'        => 'Your account has been activated successfully',
            'noPendingLogin'          => 'No pending login, please log in again',
            'incorrectPin'            => 'Incorrect PIN',
            'mustLoginFirst'          => 'You need to log in first',
            'pinMustBe4Digits'        => 'The PIN must be exactly 4 digits',
            'pinActivated'            => 'PIN activated successfully',
            'resendGeneric'           => 'If the account exists, a new activation code has been sent to your email',
            'unsupportedLang'         => 'Unsupported language',
            'unexpectedError'         => 'An unexpected error occurred',
            'dbConnectFail'           => 'Could not connect to the database',
            'listSeparator'           => ', ',
            'birthdateRequired'       => 'Please enter your date of birth',
            'invalidBirthdate'        => 'Invalid date of birth',
            'ageTooYoung'             => 'You must be at least 13 years old to create an account',
            'accountNotComplete'      => "Your account isn't fully set up yet. Please finish creating your account before logging in",
            'usernameRequired'        => 'Please enter a username',
            'usernameInvalidFormat'   => 'Username must be 3–20 characters: letters, numbers, or underscores only',
            'usernameTaken'           => 'This username is taken, try another one',
            'usernameAvailable'       => 'Username is available',
            'usernameSetSuccess'      => 'Username set successfully',
            'mustVerifyFirst'         => 'You need to verify your email first',
            'accountAlreadyComplete'  => 'Your account is already complete',
        ],
    ];

    $lang = current_lang();
    $text = $dict[$lang][$key] ?? $dict['ar'][$key] ?? $key;
    foreach ($vars as $k => $v) {
        // {minutes} يتوقع عدد صحيح ويتصاغ حسب قواعد اللغة (مفرد/مثنى/جمع
        // بالعربي) بدل لصق الرقم مباشرة قبل كلمة "دقيقة" بشكل خاطئ نحويًا.
        if ($k === 'minutes') {
            $v = $lang === 'ar' ? ar_minutes_phrase((int)$v) : en_minutes_phrase((int)$v);
        }
        $text = str_replace('{' . $k . '}', (string)$v, $text);
    }
    return $text;
}
