<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => msg('methodNotAllowed')]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!csrf_verify($data['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('sessionExpired')]);
    exit;
}

// هوية صاحب طلب إعادة التعيين تجي من جلسة السيرفر فقط (ضبطها
// forgot_password.php وقت إرسال الكود) — الطلب هنا ما يحتوي ولا يقبل
// أي حقل إيميل من المتصفح إطلاقًا، فما فيه شي بالطلب يقدر زائر يعدّله
// عشان يستهدف حساب غير حسابه.
$pendingUserId = $_SESSION['pending_reset_user_id'] ?? null;
$code     = trim($data['code'] ?? '');
$password = $data['password'] ?? '';
$ip       = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if ($pendingUserId === null) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('invalidOrExpiredLink')]);
    exit;
}
if (!preg_match('/^\d{6}$/', $code)) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('invalidData')]);
    exit;
}
if (mb_strlen($password) < 8) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('passwordMin8')]);
    exit;
}

$throttleKey = "resetcheck_uid_{$pendingUserId}";
if (too_many_attempts($pdo, $ip, $throttleKey, 8, 15)) {
    http_response_code(429);
    echo json_encode(["success" => false, "message" => msg('tooManyAttemptsShort')]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, password_hash, email_verified, reset_code, reset_code_expires, reset_code_used FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$pendingUserId]);
$user = $stmt->fetch();

if (!$user || !$user['reset_code']) {
    record_attempt($pdo, $ip, $throttleKey);
    http_response_code(404);
    echo json_encode(["success" => false, "message" => msg('invalidOrExpiredLink')]);
    exit;
}

// دفاع إضافي: ما نسمح بتغيير كلمة المرور أبدًا لحساب غير مفعّل، حتى لو
// وُجد لديه (بأي طريقة) reset_code صالح. forgot_password.php أصلًا يمنع
// إرسال كود لحساب غير مفعّل، لكن هذا الفحص هنا يضمن نفس القاعدة حتى لو
// تغيّرت حالة التفعيل بعد إرسال الكود.
if (!$user['email_verified']) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => msg('mustVerifyEmail')]);
    exit;
}

if (strtotime($user['reset_code_expires']) < time()) {
    http_response_code(410);
    echo json_encode(["success" => false, "message" => msg('codeExpired')]);
    exit;
}

if (!hash_equals($user['reset_code'], $code)) {
    record_attempt($pdo, $ip, $throttleKey);
    http_response_code(401);
    echo json_encode(["success" => false, "message" => msg('incorrectCode')]);
    exit;
}

// الكود صحيح وما انتهت صلاحيته، بس سبق واستُخدم لتغيير كلمة المرور مرة.
// ما نسمح باستخدامه مرة ثانية — لازم ينتظر المستخدم لين تنتهي مدة
// الكود القديم قبل ما يقدر يطلب/يستخدم كود جديد (نفس القرار المطبّق
// بـ forgot_password.php).
if (!empty($user['reset_code_used'])) {
    record_attempt($pdo, $ip, $throttleKey);
    $remainingMinutes = (int)ceil((strtotime($user['reset_code_expires']) - time()) / 60);
    http_response_code(410);
    echo json_encode([
        "success" => false,
        "message" => msg('codeAlreadyUsed', ['minutes' => $remainingMinutes]),
    ]);
    exit;
}

// امنع استخدام نفس كلمة المرور الحالية ككلمة مرور جديدة
if (!empty($user['password_hash']) && password_verify($password, $user['password_hash'])) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => msg('newPasswordMustDiffer')]);
    exit;
}

// عن قصد ما نمسح reset_code / reset_code_expires هنا. لو مسحناهم،
// forgot_password.php بيشوف إنه ما فيه كود سابق أبدًا وبيرسل كود جديد
// فورًا حتى لو الكود القديم لسا داخل نافذة الـ ١٥ دقيقة — وهذي كانت
// الثغرة. بدل هذا، نعلّم الكود كـ"مستخدم" بس نخلي وقت انتهائه زي ما هو،
// عشان يستمر يمنع إرسال/استخدام أي كود جديد لين تنتهي مدته الأصلية.
$newHash = password_hash($password, PASSWORD_BCRYPT);
$pdo->prepare(
    "UPDATE users SET password_hash = ?, reset_code_used = 1 WHERE id = ?"
)->execute([$newHash, $user['id']]);
unset($_SESSION['pending_reset_user_id']);

echo json_encode(["success" => true, "message" => msg('passwordChanged')]);
