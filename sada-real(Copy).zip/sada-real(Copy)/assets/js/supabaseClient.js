// ============================================================
// إعدادات الاتصال بـ Supabase
// ⚠️ عدّل السطرين التاليين ببيانات مشروعك من:
// Supabase Dashboard > Project Settings > API
// ============================================================
const SUPABASE_URL = "https://xxxxxxxxxxxxxxxx.supabase.co"; // ضع رابط مشروعك هنا
const SUPABASE_ANON_KEY = "ضع_anon_public_key_هنا"; // ضع المفتاح العام (anon) هنا فقط، أبدًا service_role

// تهيئة عميل Supabase (المكتبة يتم تحميلها عبر CDN في كل صفحة HTML)
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
